function underwater_air_func(strength)
   for ppos=0,3 do
      local char = dsb_ppos_char(ppos)
      if (valid_and_alive(char)) then
         local air_supply = ch_exvar[char].air_supply - 1
         dsb_write(system_color, dsb_get_charname(char) .. "'S AIR SUPPLY IS " .. air_supply)
         if (air_supply == 5) then
            dsb_write(system_color, dsb_get_charname(char) .. " IS RUNNING OUT OF AIR!")
	 end
         if (air_supply == 0) then
            dsb_write(system_color, dsb_get_charname(char) .. " HAS DROWNED!")
            dsb_set_bar(char, HEALTH, 0)
         else
            ch_exvar[char].air_supply = air_supply
         end
      end
   end
   return strength
end

C_UNDERWATER = dsb_add_condition(PARTY, nil, gfx.water_overlay, 10, underwater_air_func)

function go_underwater(under)
   -- Set up the condition and distortion
   local cond_val = 0
   local distort_val = 0
   if (under) then
      cond_val = 1
      distort_val = DISTORTION_UNDERWATER
   end
   dsb_set_condition(PARTY, C_UNDERWATER, cond_val)
   dsb_viewport_distort(distort_val) 

   -- Trigger the underwater sound
   if (under) then
      g_water_channel = dsb_sound(snd.water, true)
   else
      if (g_water_channel) then
         dsb_stopsound(g_water_channel)
         g_water_channel = nil
      end
   end

   -- Give everyone an air supply
   for ppos=0,3 do
      local char = dsb_ppos_char(ppos)
      if (valid_and_alive(char)) then
         use_ch_exvar(char)
         ch_exvar[char].air_supply = 12
      end
   end
end

function sys_enter_level(level)
   if (level == 1) then
      go_underwater(true)
      for id in dsb_insts() do
         local lev = dsb_get_coords(id)
         if (lev == CHARACTER or lev == MOUSE_HAND) then
            local idarch = dsb_find_arch(id)
            if (idarch.class == "TORCH") then
                 dsb_swap(id, "torch_soaked")
            end
         end
      end
   else
      go_underwater(false)
   end
end

function waterbreathing_func(who, strength)
   use_ch_exvar(who)
   ch_exvar[who].air_supply = 20
   return strength - 1
end

C_WATERBREATHING = dsb_add_condition(INDIVIDUAL, nil, nil, 5, waterbreathing_func)

function sys_forbid_magic(ppos, who)
   local level = dsb_party_coords()
   if (level == 1) then
      return true
   end

--Comment out the next two lines if you're not using the ghoul touch effect from attacks.lua in your dungeon.
   local paralyzed = dsb_get_condition(who, C_PARALYSIS)
   if (paralyzed) then return true end

   return false
end


function sys_forbid_sleep()
   local level = dsb_party_coords()
   if (level == 1) then
      return true
   end
   return false
end