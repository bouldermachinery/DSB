lua_manifest = {
    "graphics.lua",
    "sound.lua",
    "attacks.lua",
    "underwater.lua"
}

dsb_export("g_water_channel")
g_water_channel = nil

-- Code below this line can be removed if using dsb 0.47 or later.
function use_ch_exvar(who)
   if (not ch_exvar[who]) then ch_exvar[who] = { } end
end

DISTORTION_NONE = 0
DISTORTION_UNDERWATER = 1