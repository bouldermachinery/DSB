LD_LIBRARY_PATH=. ./dsb-fmod
