--Miscellaneous functions and conditions.  These are called by individual monster special attacks
function sys_character_die(ppos, who, mouse_drop)
   
   drop_all_items_and_magicshields(ppos, who, mouse_drop)
   
   local death_object
   use_ch_exvar(who)
   if (ch_exvar[who].petrified) then
      death_object = "petrified"
      dsb_replace_topimages(who, nil, nil, "top_dead_petrified")
      ch_exvar[who].petrified = nil
   else
      death_object = "bones"
      dsb_replace_topimages(who, nil, nil, 0)
   end

   local lev, xc, yc = dsb_party_coords()
   local tile_pos = dsb_ppos_tile(ppos)
   local dead_id = dsb_spawn(death_object, lev, xc, yc, tile_pos)
   exvar[dead_id] = { owner = who }

end

function paralysis_func(who, strength)
   local ppos = dsb_char_ppos(who)   
   dsb_set_idle(ppos, 6)
   if (strength > 1) then
      return strength - 1
   else
      return 0
   end
end

function psychic_explode_square(lev, xc, yc, range, dmgpower, hit_type)
    local p_at = dsb_party_at(lev, xc, yc)
    if (p_at) then
        g_mindblast_channel = dsb_sound(snd.mindblast)
        local base_dmg = (calc_fireball_damage(range, dmgpower)) * 2
        local ppos
        for ppos=0,3 do
            local who = dsb_ppos_char(ppos)
            if (valid_and_alive(who)) then
                local dmg = magic_damage(ppos, who, base_dmg, true)
                do_damage(ppos, who, MANA, dmg)
                
                local wis = dsb_get_stat(who, STAT_WIS)
                wis = wis - dmg
                if (wis < 10) then
                    dsb_set_bar(who, HEALTH, 0)
                else
                    dsb_set_stat(who, STAT_WIS, wis)
                end
            end
        end
    end
end

--[[This code is commented out because it's duplicated in underwater.lua.  If there's no underwater.lua
    in your dungeon, then put it back in.
function sys_forbid_magic(ppos, who)
   local paralyzed = dsb_get_condition(who, C_PARALYSIS)
   if (paralyzed) then
      return true
   end
   return false
end]]

C_PARALYSIS = dsb_add_condition(INDIVIDUAL, nil, nil, 5, paralysis_func)

--Monster special attacks
function petrif_special_attack(arch, id, ppos, who, dtype, damage)
   use_ch_exvar(who)
   ch_exvar[who].petrified = true
   dsb_set_bar(who, HEALTH, 0)
end

function ghoul_special_attack(arch, id, ppos, who, dtype, damage)
   local paralyzed = dsb_get_condition(who, C_PARALYSIS)
   local whoname = dsb_get_charname(who)
   if (not paralyzed) then paralyzed = 0 end
   paralyzed = paralyzed + 30
   dsb_write(system_color, whoname .. " IS PARALYZED")
   if (paralyzed > 90) then paralyzed = 90 end
   dsb_set_condition(who, C_PARALYSIS, paralyzed)
end

function mindflayer_touch(arch, id, ppos, who, dtype, damage)
   dsb_set_bar(who, HEALTH, 0)
end

function shadow_special_attack(arch, id, ppos, who, dtype, damage)
   local new_str = dsb_get_stat(who, STAT_STR) -40
   dsb_set_stat(who, STAT_STR, new_str)
end

function wight_special_attack(arch, id, ppos, who, dtype, damage)
   local new_vit = dsb_get_stat(who, STAT_VIT) -50
   dsb_set_stat(who, STAT_VIT, new_vit)
end

function wraith_special_attack(arch, id, ppos, who, dtype, damage)
   local drain = dsb_rand(250, 500)
   local new_mana = dsb_get_bar(who, MANA) - drain
   dsb_set_bar(who, MANA, new_mana)
end

--Player attacks and methods

function method_waterbreathe(name, ppos, who, what)
    local arch = dsb_find_arch(what)
    local m = lookup_method_info(name, arch)
    if (not m) then return end
        
    dsb_set_condition(who, C_WATERBREATHING, 20)
    
    method_finish(m, ppos, who, what)
end

method_info.ASSASSINATE = {
      xp_class = CLASS_NINJA,
      xp_sub = SKILL_MARTIALARTS,
      xp_get = 36,
      idleness = 16,
      stamina_used = 8,
      power = 72,
      req_luck = 50,
      ddefense = -10,
      enhanced_critical_hit = true
}

method_info.CRUSH = {
      xp_class = CLASS_FIGHTER,
      xp_sub = SKILL_BASHING,
      xp_get = 30,
      idleness = 12,
      stamina_used = 18,
      power = 56,
      req_luck = 48,
      door_basher = true,
      enhanced_critical_hit = true
}

method_info.HACK = {
      xp_class = CLASS_FIGHTER,
      xp_sub = SKILL_SWINGING,
      xp_get = 30,
      idleness = 14,
      stamina_used = 18,
      power = 60,
      req_luck = 50,
      door_basher = true,
      enhanced_critical_hit = true
}

method_info.HEW = {
      xp_class = CLASS_FIGHTER,
      xp_sub = SKILL_SWINGING,
      xp_get = 12,
      idleness = 12,
      stamina_used = 11,
      power = 48,
      req_luck = 40,
      door_basher = true,
      enhanced_critical_hit = true
}

method_info.PUMMEL = {
      xp_class = CLASS_NINJA,
      xp_sub = SKILL_MARTIALARTS,
      xp_get = 19,
      idleness = 16,
      stamina_used = 12,
      power = 60,
      req_luck = 42,
      ddefense = -10,
      enhanced_critical_hit = true
}

method_info.WATERBREATHE = {
	    xp_class = CLASS_WIZARD,
	    xp_sub = SKILL_AIR,
	    xp_get = 35,
	    idleness = 10,
	    stamina_used = 2
}