-- ************
-- * MONSTERS *
-- ************
gfx.monster_ant_attack = dsb_get_bitmap("MONSTER_ANT_ATTACK", "mfi_graphics/monster/MONSTER_ANT_ATTACK.png")
gfx.monster_ant_back = dsb_get_bitmap("MONSTER_ANT_BACK", "mfi_graphics/monster/MONSTER_ANT_BACK.png")
gfx.monster_ant_front = dsb_get_bitmap("MONSTER_ANT_FRONT", "mfi_graphics/monster/MONSTER_ANT_FRONT.png")
gfx.monster_ant_side = dsb_get_bitmap("MONSTER_ANT_SIDE", "mfi_graphics/monster/MONSTER_ANT_SIDE.png")

gfx.monster_banshee_attack = dsb_get_bitmap("MONSTER_BANSHEE_ATTACK", "mfi_graphics/monster/MONSTER_BANSHEE_ATTACK.png")
gfx.monster_banshee_back = dsb_get_bitmap("MONSTER_BANSHEE_BACK", "mfi_graphics/monster/MONSTER_BANSHEE_BACK.png")
gfx.monster_banshee_front = dsb_get_bitmap("MONSTER_BANSHEE_FRONT", "mfi_graphics/monster/MONSTER_BANSHEE_FRONT.png")
gfx.monster_banshee_side = dsb_get_bitmap("MONSTER_BANSHEE_SIDE", "mfi_graphics/monster/MONSTER_BANSHEE_SIDE.png")

gfx.monster_basilisk_attack = dsb_get_bitmap("MONSTER_BASILISK_ATTACK", "mfi_graphics/monster/MONSTER_BASILISK_ATTACK.png")
gfx.monster_basilisk_back = dsb_get_bitmap("MONSTER_BASILISK_BACK", "mfi_graphics/monster/MONSTER_BASILISK_BACK.png")
gfx.monster_basilisk_front = dsb_get_bitmap("MONSTER_BASILISK_FRONT", "mfi_graphics/monster/MONSTER_BASILISK_FRONT.png")
gfx.monster_basilisk_side = dsb_get_bitmap("MONSTER_BASILISK_SIDE", "mfi_graphics/monster/MONSTER_BASILISK_SIDE.png")

gfx.monster_beholder_attack = dsb_get_bitmap("MONSTER_BEHOLDER_ATTACK", "mfi_graphics/monster/MONSTER_BEHOLDER_ATTACK.png")
gfx.monster_beholder_back = dsb_get_bitmap("MONSTER_BEHOLDER_BACK", "mfi_graphics/monster/MONSTER_BEHOLDER_BACK.png")
gfx.monster_beholder_front = dsb_get_bitmap("MONSTER_BEHOLDER_FRONT", "mfi_graphics/monster/MONSTER_BEHOLDER_FRONT.png")
gfx.monster_beholder_side = dsb_get_bitmap("MONSTER_BEHOLDER_SIDE", "mfi_graphics/monster/MONSTER_BEHOLDER_SIDE.png")

gfx.monster_bonenaga_attack = dsb_get_bitmap("MONSTER_BONENAGA_ATTACK", "mfi_graphics/monster/MONSTER_BONENAGA_ATTACK.png")
gfx.monster_bonenaga_back = dsb_get_bitmap("MONSTER_BONENAGA_BACK", "mfi_graphics/monster/MONSTER_BONENAGA_BACK.png")
gfx.monster_bonenaga_front = dsb_get_bitmap("MONSTER_BONENAGA_FRONT", "mfi_graphics/monster/MONSTER_BONENAGA_FRONT.png")
gfx.monster_bonenaga_side = dsb_get_bitmap("MONSTER_BONENAGA_SIDE", "mfi_graphics/monster/MONSTER_BONENAGA_SIDE.png")

gfx.monster_bugbear_attack = dsb_get_bitmap("MONSTER_BUGBEAR_ATTACK", "mfi_graphics/monster/MONSTER_BUGBEAR_ATTACK.png")
gfx.monster_bugbear_back = dsb_get_bitmap("MONSTER_BUGBEAR_BACK", "mfi_graphics/monster/MONSTER_BUGBEAR_BACK.png")
gfx.monster_bugbear_front = dsb_get_bitmap("MONSTER_BUGBEAR_FRONT", "mfi_graphics/monster/MONSTER_BUGBEAR_FRONT.png")
gfx.monster_bugbear_side = dsb_get_bitmap("MONSTER_BUGBEAR_SIDE", "mfi_graphics/monster/MONSTER_BUGBEAR_SIDE.png")

gfx.monster_carrioncrawler_attack = dsb_get_bitmap("MONSTER_CARRIONCRAWLER_ATTACK", "mfi_graphics/monster/MONSTER_CARRIONCRAWLER_ATTACK.png")
gfx.monster_carrioncrawler_back = dsb_get_bitmap("MONSTER_CARRIONCRAWLER_BACK", "mfi_graphics/monster/MONSTER_CARRIONCRAWLER_BACK.png")
gfx.monster_carrioncrawler_front = dsb_get_bitmap("MONSTER_CARRIONCRAWLER_FRONT", "mfi_graphics/monster/MONSTER_CARRIONCRAWLER_FRONT.png")
gfx.monster_carrioncrawler_side = dsb_get_bitmap("MONSTER_CARRIONCRAWLER_SIDE", "mfi_graphics/monster/MONSTER_CARRIONCRAWLER_SIDE.png")

gfx.monster_cerberus_attack = dsb_get_bitmap("MONSTER_CERBERUS_ATTACK", "mfi_graphics/monster/MONSTER_CERBERUS_ATTACK.png")
gfx.monster_cerberus_back = dsb_get_bitmap("MONSTER_CERBERUS_BACK", "mfi_graphics/monster/MONSTER_CERBERUS_BACK.png")
gfx.monster_cerberus_front = dsb_get_bitmap("MONSTER_CERBERUS_FRONT", "mfi_graphics/monster/MONSTER_CERBERUS_FRONT.png")
gfx.monster_cerberus_side = dsb_get_bitmap("MONSTER_CERBERUS_SIDE", "mfi_graphics/monster/MONSTER_CERBERUS_SIDE.png")

gfx.monster_chimera_attack = dsb_get_bitmap("MONSTER_CHIMERA_ATTACK", "mfi_graphics/monster/MONSTER_CHIMERA_ATTACK.png")
gfx.monster_chimera_back = dsb_get_bitmap("MONSTER_CHIMERA_BACK", "mfi_graphics/monster/MONSTER_CHIMERA_BACK.png")
gfx.monster_chimera_front = dsb_get_bitmap("MONSTER_CHIMERA_FRONT", "mfi_graphics/monster/MONSTER_CHIMERA_FRONT.png")
gfx.monster_chimera_side = dsb_get_bitmap("MONSTER_CHIMERA_SIDE", "mfi_graphics/monster/MONSTER_CHIMERA_SIDE.png")

gfx.monster_cockatrice_attack = dsb_get_bitmap("MONSTER_COCKATRICE_ATTACK", "mfi_graphics/monster/MONSTER_COCKATRICE_ATTACK.png")
gfx.monster_cockatrice_back = dsb_get_bitmap("MONSTER_COCKATRICE_BACK", "mfi_graphics/monster/MONSTER_COCKATRICE_BACK.png")
gfx.monster_cockatrice_front = dsb_get_bitmap("MONSTER_COCKATRICE_FRONT", "mfi_graphics/monster/MONSTER_COCKATRICE_FRONT.png")
gfx.monster_cockatrice_side = dsb_get_bitmap("MONSTER_COCKATRICE_SIDE", "mfi_graphics/monster/MONSTER_COCKATRICE_SIDE.png")

gfx.monster_crab_attack = dsb_get_bitmap("MONSTER_CRAB_ATTACK", "mfi_graphics/monster/MONSTER_CRAB_ATTACK.png")
gfx.monster_crab_front = dsb_get_bitmap("MONSTER_CRAB_FRONT", "mfi_graphics/monster/MONSTER_CRAB_FRONT.png")
gfx.monster_crab_side = dsb_get_bitmap("MONSTER_CRAB_SIDE", "mfi_graphics/monster/MONSTER_CRAB_SIDE.png")
-- NB: No "back" graphic for the crab.  Use "side" for "back"; the nature of the creature means it works.

gfx.monster_deathknight_attack = dsb_get_bitmap("MONSTER_DEATHKNIGHT_ATTACK", "mfi_graphics/monster/MONSTER_DEATHKNIGHT_ATTACK.png")
gfx.monster_deathknight_back = dsb_get_bitmap("MONSTER_DEATHKNIGHT_BACK", "mfi_graphics/monster/MONSTER_DEATHKNIGHT_BACK.png")
gfx.monster_deathknight_front = dsb_get_bitmap("MONSTER_DEATHKNIGHT_FRONT", "mfi_graphics/monster/MONSTER_DEATHKNIGHT_FRONT.png")
gfx.monster_deathknight_side = dsb_get_bitmap("MONSTER_DEATHKNIGHT_SIDE", "mfi_graphics/monster/MONSTER_DEATHKNIGHT_SIDE.png")

gfx.monster_ettin_attack = dsb_get_bitmap("MONSTER_ETTIN_ATTACK", "mfi_graphics/monster/MONSTER_ETTIN_ATTACK.png")
gfx.monster_ettin_back = dsb_get_bitmap("MONSTER_ETTIN_BACK", "mfi_graphics/monster/MONSTER_ETTIN_BACK.png")
gfx.monster_ettin_front = dsb_get_bitmap("MONSTER_ETTIN_FRONT", "mfi_graphics/monster/MONSTER_ETTIN_FRONT.png")
gfx.monster_ettin_side = dsb_get_bitmap("MONSTER_ETTIN_SIDE", "mfi_graphics/monster/MONSTER_ETTIN_SIDE.png")

gfx.monster_feyr_attack = dsb_get_bitmap("MONSTER_FEYR_ATTACK", "mfi_graphics/monster/MONSTER_FEYR_ATTACK.png")
gfx.monster_feyr_back = dsb_get_bitmap("MONSTER_FEYR_BACK", "mfi_graphics/monster/MONSTER_FEYR_BACK.png")
gfx.monster_feyr_front = dsb_get_bitmap("MONSTER_FEYR_FRONT", "mfi_graphics/monster/MONSTER_FEYR_FRONT.png")
gfx.monster_feyr_side = dsb_get_bitmap("MONSTER_FEYR_SIDE", "mfi_graphics/monster/MONSTER_FEYR_SIDE.png")

gfx.monster_fish_attack = dsb_get_bitmap("MONSTER_FISH_ATTACK", "mfi_graphics/monster/MONSTER_FISH_ATTACK.png")
gfx.monster_fish_back = dsb_get_bitmap("MONSTER_FISH_BACK", "mfi_graphics/monster/MONSTER_FISH_BACK.png")
gfx.monster_fish_front = dsb_get_bitmap("MONSTER_FISH_FRONT", "mfi_graphics/monster/MONSTER_FISH_FRONT.png")
gfx.monster_fish_side = dsb_get_bitmap("MONSTER_FISH_SIDE", "mfi_graphics/monster/MONSTER_FISH_SIDE.png")

gfx.monster_gargoyle_attack = dsb_get_bitmap("MONSTER_GARGOYLE_ATTACK", "mfi_graphics/monster/MONSTER_GARGOYLE_ATTACK.png")
gfx.monster_gargoyle_back = dsb_get_bitmap("MONSTER_GARGOYLE_BACK", "mfi_graphics/monster/MONSTER_GARGOYLE_BACK.png")
gfx.monster_gargoyle_front = dsb_get_bitmap("MONSTER_GARGOYLE_FRONT", "mfi_graphics/monster/MONSTER_GARGOYLE_FRONT.png")
gfx.monster_gargoyle_side = dsb_get_bitmap("MONSTER_GARGOYLE_SIDE", "mfi_graphics/monster/MONSTER_GARGOYLE_SIDE.png")

gfx.monster_ghoul_attack = dsb_get_bitmap("MONSTER_GHOUL_ATTACK", "mfi_graphics/monster/MONSTER_GHOUL_ATTACK.png")
gfx.monster_ghoul_back = dsb_get_bitmap("MONSTER_GHOUL_BACK", "mfi_graphics/monster/MONSTER_GHOUL_BACK.png")
gfx.monster_ghoul_front = dsb_get_bitmap("MONSTER_GHOUL_FRONT", "mfi_graphics/monster/MONSTER_GHOUL_FRONT.png")
gfx.monster_ghoul_side = dsb_get_bitmap("MONSTER_GHOUL_SIDE", "mfi_graphics/monster/MONSTER_GHOUL_SIDE.png")

gfx.monster_gnoll_attack = dsb_get_bitmap("MONSTER_GNOLL_ATTACK", "mfi_graphics/monster/MONSTER_GNOLL_ATTACK.png")
gfx.monster_gnoll_back = dsb_get_bitmap("MONSTER_GNOLL_BACK", "mfi_graphics/monster/MONSTER_GNOLL_BACK.png")
gfx.monster_gnoll_front = dsb_get_bitmap("MONSTER_GNOLL_FRONT", "mfi_graphics/monster/MONSTER_GNOLL_FRONT.png")
gfx.monster_gnoll_side = dsb_get_bitmap("MONSTER_GNOLL_SIDE", "mfi_graphics/monster/MONSTER_GNOLL_SIDE.png")

gfx.monster_goblin_attack = dsb_get_bitmap("MONSTER_GOBLIN_ATTACK", "mfi_graphics/monster/MONSTER_GOBLIN_ATTACK.png")
gfx.monster_goblin_back = dsb_get_bitmap("MONSTER_GOBLIN_BACK", "mfi_graphics/monster/MONSTER_GOBLIN_BACK.png")
gfx.monster_goblin_front = dsb_get_bitmap("MONSTER_GOBLIN_FRONT", "mfi_graphics/monster/MONSTER_GOBLIN_FRONT.png")
gfx.monster_goblin_side = dsb_get_bitmap("MONSTER_GOBLIN_SIDE", "mfi_graphics/monster/MONSTER_GOBLIN_SIDE.png")

gfx.monster_guardian_attack = dsb_get_bitmap("MONSTER_GUARDIAN_ATTACK", "mfi_graphics/monster/MONSTER_GUARDIAN_ATTACK.png")
gfx.monster_guardian_back = dsb_get_bitmap("MONSTER_GUARDIAN_BACK", "mfi_graphics/monster/MONSTER_GUARDIAN_BACK.png")
gfx.monster_guardian_front = dsb_get_bitmap("MONSTER_GUARDIAN_FRONT", "mfi_graphics/monster/MONSTER_GUARDIAN_FRONT.png")
gfx.monster_guardian_side = dsb_get_bitmap("MONSTER_GUARDIAN_SIDE", "mfi_graphics/monster/MONSTER_GUARDIAN_SIDE.png")

gfx.monster_harpy_attack = dsb_get_bitmap("MONSTER_HARPY_ATTACK", "mfi_graphics/monster/MONSTER_HARPY_ATTACK.png")
gfx.monster_harpy_back = dsb_get_bitmap("MONSTER_HARPY_BACK", "mfi_graphics/monster/MONSTER_HARPY_BACK.png")
gfx.monster_harpy_front = dsb_get_bitmap("MONSTER_HARPY_FRONT", "mfi_graphics/monster/MONSTER_HARPY_FRONT.png")
gfx.monster_harpy_side = dsb_get_bitmap("MONSTER_HARPY_SIDE", "mfi_graphics/monster/MONSTER_HARPY_SIDE.png")

gfx.monster_hobgoblin_attack = dsb_get_bitmap("MONSTER_HOBGOBLIN_ATTACK", "mfi_graphics/monster/MONSTER_HOBGOBLIN_ATTACK.png")
gfx.monster_hobgoblin_back = dsb_get_bitmap("MONSTER_HOBGOBLIN_BACK", "mfi_graphics/monster/MONSTER_HOBGOBLIN_BACK.png")
gfx.monster_hobgoblin_front = dsb_get_bitmap("MONSTER_HOBGOBLIN_FRONT", "mfi_graphics/monster/MONSTER_HOBGOBLIN_FRONT.png")
gfx.monster_hobgoblin_side = dsb_get_bitmap("MONSTER_HOBGOBLIN_SIDE", "mfi_graphics/monster/MONSTER_HOBGOBLIN_SIDE.png")

gfx.monster_kobold_attack = dsb_get_bitmap("MONSTER_KOBOLD_ATTACK", "mfi_graphics/monster/MONSTER_KOBOLD_ATTACK.png")
gfx.monster_kobold_back = dsb_get_bitmap("MONSTER_KOBOLD_BACK", "mfi_graphics/monster/MONSTER_KOBOLD_BACK.png")
gfx.monster_kobold_front = dsb_get_bitmap("MONSTER_KOBOLD_FRONT", "mfi_graphics/monster/MONSTER_KOBOLD_FRONT.png")
gfx.monster_kobold_side = dsb_get_bitmap("MONSTER_KOBOLD_SIDE", "mfi_graphics/monster/MONSTER_KOBOLD_SIDE.png")

gfx.monster_leech_attack = dsb_get_bitmap("MONSTER_LEECH_ATTACK", "mfi_graphics/monster/MONSTER_LEECH_ATTACK.png")
gfx.monster_leech_back = dsb_get_bitmap("MONSTER_LEECH_BACK", "mfi_graphics/monster/MONSTER_LEECH_BACK.png")
gfx.monster_leech_front = dsb_get_bitmap("MONSTER_LEECH_FRONT", "mfi_graphics/monster/MONSTER_LEECH_FRONT.png")
gfx.monster_leech_side = dsb_get_bitmap("MONSTER_LEECH_SIDE", "mfi_graphics/monster/MONSTER_LEECH_SIDE.png")

gfx.monster_lizardman_attack = dsb_get_bitmap("MONSTER_LIZARDMAN_ATTACK", "mfi_graphics/monster/MONSTER_LIZARDMAN_ATTACK.png")
gfx.monster_lizardman_back = dsb_get_bitmap("MONSTER_LIZARDMAN_BACK", "mfi_graphics/monster/MONSTER_LIZARDMAN_BACK.png")
gfx.monster_lizardman_front = dsb_get_bitmap("MONSTER_LIZARDMAN_FRONT", "mfi_graphics/monster/MONSTER_LIZARDMAN_FRONT.png")
gfx.monster_lizardman_side = dsb_get_bitmap("MONSTER_LIZARDMAN_SIDE", "mfi_graphics/monster/MONSTER_LIZARDMAN_SIDE.png")

gfx.monster_medusa_snake_attack = dsb_get_bitmap("MONSTER_MEDUSA_SNAKE_ATTACK", "mfi_graphics/monster/MONSTER_MEDUSA_SNAKE_ATTACK.png")
gfx.monster_medusa_snake_back = dsb_get_bitmap("MONSTER_MEDUSA_SNAKE_BACK", "mfi_graphics/monster/MONSTER_MEDUSA_SNAKE_BACK.png")
gfx.monster_medusa_snake_front = dsb_get_bitmap("MONSTER_MEDUSA_SNAKE_FRONT", "mfi_graphics/monster/MONSTER_MEDUSA_SNAKE_FRONT.png")
gfx.monster_medusa_snake_side = dsb_get_bitmap("MONSTER_MEDUSA_SNAKE_SIDE", "mfi_graphics/monster/MONSTER_MEDUSA_SNAKE_SIDE.png")

gfx.monster_medusa_woman_attack = dsb_get_bitmap("MONSTER_MEDUSA_WOMAN_ATTACK", "mfi_graphics/monster/MONSTER_MEDUSA_WOMAN_ATTACK.png")
gfx.monster_medusa_woman_back = dsb_get_bitmap("MONSTER_MEDUSA_WOMAN_BACK", "mfi_graphics/monster/MONSTER_MEDUSA_WOMAN_BACK.png")
gfx.monster_medusa_woman_front = dsb_get_bitmap("MONSTER_MEDUSA_WOMAN_FRONT", "mfi_graphics/monster/MONSTER_MEDUSA_WOMAN_FRONT.png")
gfx.monster_medusa_woman_side = dsb_get_bitmap("MONSTER_MEDUSA_WOMAN_SIDE", "mfi_graphics/monster/MONSTER_MEDUSA_WOMAN_SIDE.png")

gfx.monster_mindflayer_attack = dsb_get_bitmap("MONSTER_MINDFLAYER_ATTACK", "mfi_graphics/monster/MONSTER_MINDFLAYER_ATTACK.png")
gfx.monster_mindflayer_back = dsb_get_bitmap("MONSTER_MINDFLAYER_BACK", "mfi_graphics/monster/MONSTER_MINDFLAYER_BACK.png")
gfx.monster_mindflayer_front = dsb_get_bitmap("MONSTER_MINDFLAYER_FRONT", "mfi_graphics/monster/MONSTER_MINDFLAYER_FRONT.png")
gfx.monster_mindflayer_side = dsb_get_bitmap("MONSTER_MINDFLAYER_SIDE", "mfi_graphics/monster/MONSTER_MINDFLAYER_SIDE.png")

gfx.monster_minotaur_attack = dsb_get_bitmap("MONSTER_MINOTAUR_ATTACK", "mfi_graphics/monster/MONSTER_MINOTAUR_ATTACK.png")
gfx.monster_minotaur_back = dsb_get_bitmap("MONSTER_MINOTAUR_BACK", "mfi_graphics/monster/MONSTER_MINOTAUR_BACK.png")
gfx.monster_minotaur_front = dsb_get_bitmap("MONSTER_MINOTAUR_FRONT", "mfi_graphics/monster/MONSTER_MINOTAUR_FRONT.png")
gfx.monster_minotaur_side = dsb_get_bitmap("MONSTER_MINOTAUR_SIDE", "mfi_graphics/monster/MONSTER_MINOTAUR_SIDE.png")

gfx.monster_mudman_attack = dsb_get_bitmap("MONSTER_MUDMAN_ATTACK", "mfi_graphics/monster/MONSTER_MUDMAN_ATTACK.png")
gfx.monster_mudman_back = dsb_get_bitmap("MONSTER_MUDMAN_BACK", "mfi_graphics/monster/MONSTER_MUDMAN_BACK.png")
gfx.monster_mudman_front = dsb_get_bitmap("MONSTER_MUDMAN_FRONT", "mfi_graphics/monster/MONSTER_MUDMAN_FRONT.png")
gfx.monster_mudman_side = dsb_get_bitmap("MONSTER_MUDMAN_SIDE", "mfi_graphics/monster/MONSTER_MUDMAN_SIDE.png")

gfx.monster_ogreslug_attack = dsb_get_bitmap("MONSTER_OGRESLUG_ATTACK", "mfi_graphics/monster/MONSTER_OGRESLUG_ATTACK.png")
gfx.monster_ogreslug_back = dsb_get_bitmap("MONSTER_OGRESLUG_BACK", "mfi_graphics/monster/MONSTER_OGRESLUG_BACK.png")
gfx.monster_ogreslug_front = dsb_get_bitmap("MONSTER_OGRESLUG_FRONT", "mfi_graphics/monster/MONSTER_OGRESLUG_FRONT.png")
gfx.monster_ogreslug_side = dsb_get_bitmap("MONSTER_OGRESLUG_SIDE", "mfi_graphics/monster/MONSTER_OGRESLUG_SIDE.png")

gfx.monster_orc_attack = dsb_get_bitmap("MONSTER_ORC_ATTACK", "mfi_graphics/monster/MONSTER_ORC_ATTACK.png")
gfx.monster_orc_back = dsb_get_bitmap("MONSTER_ORC_BACK", "mfi_graphics/monster/MONSTER_ORC_BACK.png")
gfx.monster_orc_front = dsb_get_bitmap("MONSTER_ORC_FRONT", "mfi_graphics/monster/MONSTER_ORC_FRONT.png")
gfx.monster_orc_side = dsb_get_bitmap("MONSTER_ORC_SIDE", "mfi_graphics/monster/MONSTER_ORC_SIDE.png")

gfx.monster_otyugh_attack = dsb_get_bitmap("MONSTER_OTYUGH_ATTACK", "mfi_graphics/monster/MONSTER_OTYUGH_ATTACK.png")
gfx.monster_otyugh_back = dsb_get_bitmap("MONSTER_OTYUGH_BACK", "mfi_graphics/monster/MONSTER_OTYUGH_BACK.png")
gfx.monster_otyugh_front = dsb_get_bitmap("MONSTER_OTYUGH_FRONT", "mfi_graphics/monster/MONSTER_OTYUGH_FRONT.png")
gfx.monster_otyugh_side = dsb_get_bitmap("MONSTER_OTYUGH_SIDE", "mfi_graphics/monster/MONSTER_OTYUGH_SIDE.png")

gfx.monster_poltergeist_attack = dsb_get_bitmap("MONSTER_POLTERGEIST_ATTACK", "mfi_graphics/monster/MONSTER_POLTERGEIST_ATTACK.png")
gfx.monster_poltergeist_back = dsb_get_bitmap("MONSTER_POLTERGEIST_BACK", "mfi_graphics/monster/MONSTER_POLTERGEIST_BACK.png")
gfx.monster_poltergeist_front = dsb_get_bitmap("MONSTER_POLTERGEIST_FRONT", "mfi_graphics/monster/MONSTER_POLTERGEIST_FRONT.png")
gfx.monster_poltergeist_side = dsb_get_bitmap("MONSTER_POLTERGEIST_SIDE", "mfi_graphics/monster/MONSTER_POLTERGEIST_SIDE.png")

gfx.monster_seaspirit_attack = dsb_get_bitmap("MONSTER_SEASPIRIT_ATTACK", "mfi_graphics/monster/MONSTER_SEASPIRIT_ATTACK.png")
gfx.monster_seaspirit_back = dsb_get_bitmap("MONSTER_SEASPIRIT_BACK", "mfi_graphics/monster/MONSTER_SEASPIRIT_BACK.png")
gfx.monster_seaspirit_front = dsb_get_bitmap("MONSTER_SEASPIRIT_FRONT", "mfi_graphics/monster/MONSTER_SEASPIRIT_FRONT.png")
gfx.monster_seaspirit_side = dsb_get_bitmap("MONSTER_SEASPIRIT_SIDE", "mfi_graphics/monster/MONSTER_SEASPIRIT_SIDE.png")

gfx.monster_shadow_attack = dsb_get_bitmap("MONSTER_SHADOW_ATTACK", "mfi_graphics/monster/MONSTER_SHADOW_ATTACK.png")
gfx.monster_shadow_back = dsb_get_bitmap("MONSTER_SHADOW_BACK", "mfi_graphics/monster/MONSTER_SHADOW_BACK.png")
gfx.monster_shadow_front = dsb_get_bitmap("MONSTER_SHADOW_FRONT", "mfi_graphics/monster/MONSTER_SHADOW_FRONT.png")
gfx.monster_shadow_side = dsb_get_bitmap("MONSTER_SHADOW_SIDE", "mfi_graphics/monster/MONSTER_SHADOW_SIDE.png")

gfx.monster_shamblingmound_attack = dsb_get_bitmap("MONSTER_SHAMBLINGMOUND_ATTACK", "mfi_graphics/monster/MONSTER_SHAMBLINGMOUND_ATTACK.png")
gfx.monster_shamblingmound_back = dsb_get_bitmap("MONSTER_SHAMBLINGMOUND_BACK", "mfi_graphics/monster/MONSTER_SHAMBLINGMOUND_BACK.png")
gfx.monster_shamblingmound_front = dsb_get_bitmap("MONSTER_SHAMBLINGMOUND_FRONT", "mfi_graphics/monster/MONSTER_SHAMBLINGMOUND_FRONT.png")
gfx.monster_shamblingmound_side = dsb_get_bitmap("MONSTER_SHAMBLINGMOUND_SIDE", "mfi_graphics/monster/MONSTER_SHAMBLINGMOUND_SIDE.png")

gfx.monster_skeleton1_attack = dsb_get_bitmap("MONSTER_SKELETON1_ATTACK", "mfi_graphics/monster/MONSTER_SKELETON1_ATTACK.png")
gfx.monster_skeleton1_back = dsb_get_bitmap("MONSTER_SKELETON1_BACK", "mfi_graphics/monster/MONSTER_SKELETON1_BACK.png")
gfx.monster_skeleton1_front = dsb_get_bitmap("MONSTER_SKELETON1_FRONT", "mfi_graphics/monster/MONSTER_SKELETON1_FRONT.png")
gfx.monster_skeleton1_side = dsb_get_bitmap("MONSTER_SKELETON1_SIDE", "mfi_graphics/monster/MONSTER_SKELETON1_SIDE.png")

gfx.monster_skeletonwarrior_attack = dsb_get_bitmap("MONSTER_SKELETONWARRIOR_ATTACK", "mfi_graphics/monster/MONSTER_SKELETONWARRIOR_ATTACK.png")
gfx.monster_skeletonwarrior_back = dsb_get_bitmap("MONSTER_SKELETONWARRIOR_BACK", "mfi_graphics/monster/MONSTER_SKELETONWARRIOR_ATTACK.png")
gfx.monster_skeletonwarrior_front = dsb_get_bitmap("MONSTER_SKELETONWARRIOR_FRONT", "mfi_graphics/monster/MONSTER_SKELETONWARRIOR_FRONT.png")
gfx.monster_skeletonwarrior_side = dsb_get_bitmap("MONSTER_SKELETONWARRIOR_SIDE", "mfi_graphics/monster/MONSTER_SKELETONWARRIOR_SIDE.png")

gfx.monster_sorceror_attack = dsb_get_bitmap("MONSTER_SORCEROR_ATTACK", "mfi_graphics/monster/MONSTER_SORCEROR_ATTACK.png")
gfx.monster_sorceror_back = dsb_get_bitmap("MONSTER_SORCEROR_BACK", "mfi_graphics/monster/MONSTER_SORCEROR_BACK.png")
gfx.monster_sorceror_front = dsb_get_bitmap("MONSTER_SORCEROR_FRONT", "mfi_graphics/monster/MONSTER_SORCEROR_FRONT.png")
gfx.monster_sorceror_side = dsb_get_bitmap("MONSTER_SORCEROR_SIDE", "mfi_graphics/monster/MONSTER_SORCEROR_SIDE.png")

gfx.monster_sorceror1_attack = dsb_get_bitmap("MONSTER_SORCEROR1_ATTACK", "mfi_graphics/monster/MONSTER_SORCEROR1_ATTACK.png")
gfx.monster_sorceror1_back = dsb_get_bitmap("MONSTER_SORCEROR1_BACK", "mfi_graphics/monster/MONSTER_SORCEROR1_BACK.png")
gfx.monster_sorceror1_front = dsb_get_bitmap("MONSTER_SORCEROR1_FRONT", "mfi_graphics/monster/MONSTER_SORCEROR1_FRONT.png")
gfx.monster_sorceror1_side = dsb_get_bitmap("MONSTER_SORCEROR1_SIDE", "mfi_graphics/monster/MONSTER_SORCEROR1_SIDE.png")

gfx.monster_spider_attack = dsb_get_bitmap("MONSTER_SPIDER_ATTACK", "mfi_graphics/monster/MONSTER_SPIDER_ATTACK.png")
gfx.monster_spider_back = dsb_get_bitmap("MONSTER_SPIDER_BACK", "mfi_graphics/monster/MONSTER_SPIDER_BACK.png")
gfx.monster_spider_front = dsb_get_bitmap("MONSTER_SPIDER_FRONT", "mfi_graphics/monster/MONSTER_SPIDER_FRONT.png")
gfx.monster_spider_side = dsb_get_bitmap("MONSTER_SPIDER_SIDE", "mfi_graphics/monster/MONSTER_SPIDER_SIDE.png")

gfx.monster_spider_brown_attack = dsb_get_bitmap("MONSTER_SPIDER_BROWN_ATTACK", "mfi_graphics/monster/MONSTER_SPIDER_BROWN_ATTACK.png")
gfx.monster_spider_brown_back = dsb_get_bitmap("MONSTER_SPIDER_BROWN_BACK", "mfi_graphics/monster/MONSTER_SPIDER_BROWN_BACK.png")
gfx.monster_spider_brown_front = dsb_get_bitmap("MONSTER_SPIDER_BROWN_FRONT", "mfi_graphics/monster/MONSTER_SPIDER_BROWN_FRONT.png")
gfx.monster_spider_brown_side = dsb_get_bitmap("MONSTER_SPIDER_BROWN_SIDE", "mfi_graphics/monster/MONSTER_SPIDER_BROWN_SIDE.png")

gfx.monster_tree1_attack = dsb_get_bitmap("MONSTER_TREE1_ATTACK", "mfi_graphics/monster/MONSTER_TREE1_ATTACK.png")
gfx.monster_tree1_front = dsb_get_bitmap("MONSTER_TREE1_FRONT", "mfi_graphics/monster/MONSTER_TREE1_FRONT.png")

gfx.monster_tree2_attack = dsb_get_bitmap("MONSTER_TREE2_ATTACK", "mfi_graphics/monster/MONSTER_TREE2_ATTACK.png")
gfx.monster_tree2_front = dsb_get_bitmap("MONSTER_TREE2_FRONT", "mfi_graphics/monster/MONSTER_TREE2_FRONT.png")

gfx.monster_tree3_attack = dsb_get_bitmap("MONSTER_TREE3_ATTACK", "mfi_graphics/monster/MONSTER_TREE3_ATTACK.png")
gfx.monster_tree3_front = dsb_get_bitmap("MONSTER_TREE3_FRONT", "mfi_graphics/monster/MONSTER_TREE3_FRONT.png")

gfx.monster_troll_attack = dsb_get_bitmap("MONSTER_TROLL_ATTACK", "mfi_graphics/monster/MONSTER_TROLL_ATTACK.png")
gfx.monster_troll_back = dsb_get_bitmap("MONSTER_TROLL_BACK", "mfi_graphics/monster/MONSTER_TROLL_BACK.png")
gfx.monster_troll_front = dsb_get_bitmap("MONSTER_TROLL_FRONT", "mfi_graphics/monster/MONSTER_TROLL_FRONT.png")
gfx.monster_troll_side = dsb_get_bitmap("MONSTER_TROLL_SIDE", "mfi_graphics/monster/MONSTER_TROLL_SIDE.png")

gfx.monster_umberhulk_attack = dsb_get_bitmap("MONSTER_UMBERHULK_ATTACK", "mfi_graphics/monster/MONSTER_UMBERHULK_ATTACK.png")
gfx.monster_umberhulk_back = dsb_get_bitmap("MONSTER_UMBERHULK_BACK", "mfi_graphics/monster/MONSTER_UMBERHULK_BACK.png")
gfx.monster_umberhulk_front = dsb_get_bitmap("MONSTER_UMBERHULK_FRONT", "mfi_graphics/monster/MONSTER_UMBERHULK_FRONT.png")
gfx.monster_umberhulk_side = dsb_get_bitmap("MONSTER_UMBERHULK_SIDE", "mfi_graphics/monster/MONSTER_UMBERHULK_SIDE.png")

gfx.monster_undeadbeast_attack = dsb_get_bitmap("MONSTER_UNDEADBEAST_ATTACK", "mfi_graphics/monster/MONSTER_UNDEADBEAST_ATTACK.png")
gfx.monster_undeadbeast_back = dsb_get_bitmap("MONSTER_UNDEADBEAST_BACK", "mfi_graphics/monster/MONSTER_UNDEADBEAST_BACK.png")
gfx.monster_undeadbeast_front = dsb_get_bitmap("MONSTER_UNDEADBEAST_FRONT", "mfi_graphics/monster/MONSTER_UNDEADBEAST_FRONT.png")
gfx.monster_undeadbeast_side = dsb_get_bitmap("MONSTER_UNDEADBEAST_SIDE", "mfi_graphics/monster/MONSTER_UNDEADBEAST_SIDE.png")

gfx.monster_waterelemental_attack = dsb_get_bitmap("MONSTER_WATERELEMENTAL_ATTACK", "mfi_graphics/monster/MONSTER_WATERELEMENTAL_ATTACK.png")
gfx.monster_waterelemental_back = dsb_get_bitmap("MONSTER_WATERELEMENTAL_BACK", "mfi_graphics/monster/MONSTER_WATERELEMENTAL_BACK.png")
gfx.monster_waterelemental_front = dsb_get_bitmap("MONSTER_WATERELEMENTAL_FRONT", "mfi_graphics/monster/MONSTER_WATERELEMENTAL_FRONT.png")
gfx.monster_waterelemental_side = dsb_get_bitmap("MONSTER_WATERELEMENTAL_SIDE", "mfi_graphics/monster/MONSTER_WATERELEMENTAL_SIDE.png")

gfx.monster_waterweird_attack = dsb_get_bitmap("MONSTER_WATERWEIRD_ATTACK", "mfi_graphics/monster/MONSTER_WATERWEIRD_ATTACK.png")
gfx.monster_waterweird_back = dsb_get_bitmap("MONSTER_WATERWEIRD_BACK", "mfi_graphics/monster/MONSTER_WATERWEIRD_BACK.png")
gfx.monster_waterweird_front = dsb_get_bitmap("MONSTER_WATERWEIRD_FRONT", "mfi_graphics/monster/MONSTER_WATERWEIRD_FRONT.png")
gfx.monster_waterweird_side = dsb_get_bitmap("MONSTER_WATERWEIRD_SIDE", "mfi_graphics/monster/MONSTER_WATERWEIRD_SIDE.png")

gfx.monster_wight_attack = dsb_get_bitmap("MONSTER_WIGHT_ATTACK", "mfi_graphics/monster/MONSTER_WIGHT_ATTACK.png")
gfx.monster_wight_back = dsb_get_bitmap("MONSTER_WIGHT_BACK", "mfi_graphics/monster/MONSTER_WIGHT_BACK.png")
gfx.monster_wight_front = dsb_get_bitmap("MONSTER_WIGHT_FRONT", "mfi_graphics/monster/MONSTER_WIGHT_FRONT.png")
gfx.monster_wight_side = dsb_get_bitmap("MONSTER_WIGHT_SIDE", "mfi_graphics/monster/MONSTER_WIGHT_SIDE.png")

gfx.monster_witch_attack = dsb_get_bitmap("MONSTER_WITCH_ATTACK", "mfi_graphics/monster/MONSTER_WITCH_ATTACK.png")
gfx.monster_witch_back = dsb_get_bitmap("MONSTER_WITCH_BACK", "mfi_graphics/monster/MONSTER_WITCH_BACK.png")
gfx.monster_witch_front = dsb_get_bitmap("MONSTER_WITCH_FRONT", "mfi_graphics/monster/MONSTER_WITCH_FRONT.png")
gfx.monster_witch_side = dsb_get_bitmap("MONSTER_WITCH_SIDE", "mfi_graphics/monster/MONSTER_WITCH_SIDE.png")

gfx.monster_wraith_attack = dsb_get_bitmap("MONSTER_WRAITH_ATTACK", "mfi_graphics/monster/MONSTER_WRAITH_ATTACK.png")
gfx.monster_wraith_back = dsb_get_bitmap("MONSTER_WRAITH_BACK", "mfi_graphics/monster/MONSTER_WRAITH_BACK.png")
gfx.monster_wraith_front = dsb_get_bitmap("MONSTER_WRAITH_FRONT", "mfi_graphics/monster/MONSTER_WRAITH_FRONT.png")
gfx.monster_wraith_side = dsb_get_bitmap("MONSTER_WRAITH_SIDE", "mfi_graphics/monster/MONSTER_WRAITH_SIDE.png")

gfx.monster_wyvern_attack = dsb_get_bitmap("MONSTER_WYVERN_ATTACK", "mfi_graphics/monster/MONSTER_WYVERN_ATTACK.png")
gfx.monster_wyvern_back = dsb_get_bitmap("MONSTER_WYVERN_BACK", "mfi_graphics/monster/MONSTER_WYVERN_BACK.png")
gfx.monster_wyvern_front = dsb_get_bitmap("MONSTER_WYVERN_FRONT", "mfi_graphics/monster/MONSTER_WYVERN_FRONT.png")
gfx.monster_wyvern_side = dsb_get_bitmap("MONSTER_WYVERN_SIDE", "mfi_graphics/monster/MONSTER_WYVERN_SIDE.png")

gfx.monster_xorn_attack = dsb_get_bitmap("MONSTER_XORN_ATTACK", "mfi_graphics/monster/MONSTER_XORN_ATTACK.png")
gfx.monster_xorn_back = dsb_get_bitmap("MONSTER_XORN_BACK", "mfi_graphics/monster/MONSTER_XORN_BACK.png")
gfx.monster_xorn_front = dsb_get_bitmap("MONSTER_XORN_FRONT", "mfi_graphics/monster/MONSTER_XORN_FRONT.png")
gfx.monster_xorn_side = dsb_get_bitmap("MONSTER_XORN_SIDE", "mfi_graphics/monster/MONSTER_XORN_SIDE.png")

gfx.monster_zombie_attack = dsb_get_bitmap("MONSTER_ZOMBIE_ATTACK", "mfi_graphics/monster/MONSTER_ZOMBIE_ATTACK.png")
gfx.monster_zombie_back = dsb_get_bitmap("MONSTER_ZOMBIE_BACK", "mfi_graphics/monster/MONSTER_ZOMBIE_BACK.png")
gfx.monster_zombie_front = dsb_get_bitmap("MONSTER_ZOMBIE_FRONT", "mfi_graphics/monster/MONSTER_ZOMBIE_FRONT.png")
gfx.monster_zombie_side = dsb_get_bitmap("MONSTER_ZOMBIE_SIDE", "mfi_graphics/monster/MONSTER_ZOMBIE_SIDE.png")

-- **********
-- * THINGS *
-- **********
gfx.thing_icon_berries = dsb_get_bitmap("THING_ICON_BERRIES", "mfi_graphics/thing/THING_ICON_BERRIES.png")
gfx.thing_dungeon_berries = dsb_get_bitmap("THING_DUNGEON_BERRIES", "mfi_graphics/thing/THING_DUNGEON_BERRIES.png")

gfx.thing_icon_bag_open = dsb_get_bitmap("THING_ICON_BAG_OPEN", "mfi_graphics/thing/THING_ICON_BAG_OPEN.png")
gfx.thing_icon_bag_closed = dsb_get_bitmap("THING_ICON_BAG_CLOSED", "mfi_graphics/thing/THING_ICON_BAG_CLOSED.png")
gfx.thing_subrenderer_bag = dsb_get_bitmap("THING_SUBRENDERER_BAG", "mfi_graphics/thing/THING_SUBRENDERER_BAG.png")
gfx.thing_dungeon_bag = dsb_get_bitmap("THING_DUNGEON_BAG", "mfi_graphics/thing/THING_DUNGEON_BAG.png")

gfx.thing_dungeon_book = dsb_get_bitmap("THING_DUNGEON_BOOK", "mfi_graphics/thing/THING_DUNGEON_BOOK.png")
gfx.thing_icon_book1 = dsb_get_bitmap("THING_ICON_BOOK1", "mfi_graphics/thing/THING_ICON_BOOK1.png")
gfx.thing_icon_book2 = dsb_get_bitmap("THING_ICON_BOOK2", "mfi_graphics/thing/THING_ICON_BOOK2.png")
gfx.thing_icon_book3 = dsb_get_bitmap("THING_ICON_BOOK3", "mfi_graphics/thing/THING_ICON_BOOK3.png")
gfx.thing_icon_book4 = dsb_get_bitmap("THING_ICON_BOOK4", "mfi_graphics/thing/THING_ICON_BOOK4.png")
gfx.thing_icon_book5 = dsb_get_bitmap("THING_ICON_BOOK5", "mfi_graphics/thing/THING_ICON_BOOK5.png")
gfx.thing_icon_book6 = dsb_get_bitmap("THING_ICON_BOOK6", "mfi_graphics/thing/THING_ICON_BOOK6.png")
gfx.thing_icon_book7 = dsb_get_bitmap("THING_ICON_BOOK7", "mfi_graphics/thing/THING_ICON_BOOK7.png")
gfx.thing_icon_book8 = dsb_get_bitmap("THING_ICON_BOOK8", "mfi_graphics/thing/THING_ICON_BOOK8.png")
gfx.thing_icon_book9 = dsb_get_bitmap("THING_ICON_BOOK9", "mfi_graphics/thing/THING_ICON_BOOK9.png")
gfx.thing_icon_book10 = dsb_get_bitmap("THING_ICON_BOOK10", "mfi_graphics/thing/THING_ICON_BOOK10.png")
gfx.thing_icon_book11 = dsb_get_bitmap("THING_ICON_BOOK11", "mfi_graphics/thing/THING_ICON_BOOK11.png")
gfx.thing_icon_book12 = dsb_get_bitmap("THING_ICON_BOOK12", "mfi_graphics/thing/THING_ICON_BOOK12.png")
gfx.thing_icon_book13 = dsb_get_bitmap("THING_ICON_BOOK13", "mfi_graphics/thing/THING_ICON_BOOK13.png")

gfx.thing_icon_brigandine_f = dsb_get_bitmap("THING_ICON_BRIGANDINE_F", "mfi_graphics/thing/THING_ICON_BRIGANDINE_F.png")
gfx.thing_icon_brigandine_m = dsb_get_bitmap("THING_ICON_BRIGANDINE_M", "mfi_graphics/thing/THING_ICON_BRIGANDINE_M.png")
gfx.thing_icon_brigandine_legs_f = dsb_get_bitmap("THING_ICON_BRIGANDINE_LEGS_F", "mfi_graphics/thing/THING_ICON_BRIGANDINE_LEGS_F.png")
gfx.thing_icon_brigandine_legs_m = dsb_get_bitmap("THING_ICON_BRIGANDINE_LEGS_M", "mfi_graphics/thing/THING_ICON_BRIGANDINE_LEGS_M.png")
gfx.thing_dungeon_brigandine = dsb_get_bitmap("THING_DUNGEON_BRIGANDINE", "mfi_graphics/thing/THING_DUNGEON_BRIGANDINE.png")
gfx.thing_dungeon_brigandine_legs = dsb_get_bitmap("THING_DUNGEON_BRIGANDINE_LEGS", "mfi_graphics/thing/THING_DUNGEON_BRIGANDINE_LEGS.png")

gfx.thing_icon_bottle = dsb_get_bitmap("THING_ICON_BOTTLE", "mfi_graphics/thing/THING_ICON_BOTTLE.png")
gfx.thing_dungeon_bottle = dsb_get_bitmap("THING_DUNGEON_BOTTLE", "mfi_graphics/thing/THING_DUNGEON_BOTTLE.png")

gfx.thing_icon_chalice = dsb_get_bitmap("THING_ICON_CHALICE", "mfi_graphics/thing/THING_ICON_CHALICE.png")
gfx.thing_dungeon_chalice = dsb_get_bitmap("THING_DUNGEON_CHALICE", "mfi_graphics/thing/THING_DUNGEON_CHALICE.png")

gfx.thing_icon_chalice_empty = dsb_get_bitmap("THING_ICON_CHALICE_EMPTY", "mfi_graphics/thing/THING_ICON_CHALICE_EMPTY.png")
gfx.thing_dungeon_chalice_empty = dsb_get_bitmap("THING_DUNGEON_CHALICE_EMPTY", "mfi_graphics/thing/THING_DUNGEON_CHALICE_EMPTY.png")

gfx.thing_icon_crown = dsb_get_bitmap("THING_ICON_CROWN", "mfi_graphics/thing/THING_ICON_CROWN.png")
gfx.thing_dungeon_crown = dsb_get_bitmap("THING_DUNGEON_CROWN", "mfi_graphics/thing/THING_DUNGEON_CROWN.png")

gfx.thing_icon_decapitator = dsb_get_bitmap("THING_ICON_DECAPITATOR", "mfi_graphics/thing/THING_ICON_DECAPITATOR.png")

gfx.thing_icon_dwarfaxe = dsb_get_bitmap("THING_ICON_DWARFAXE", "mfi_graphics/thing/THING_ICON_DWARFAXE.png")

gfx.thing_icon_egg = dsb_get_bitmap("THING_ICON_EGG", "mfi_graphics/thing/THING_ICON_EGG.png")
gfx.thing_dungeon_egg = dsb_get_bitmap("THING_DUNGEON_EGG", "mfi_graphics/thing/THING_DUNGEON_EGG.png")

gfx.thing_icon_eyeball = dsb_get_bitmap("THING_ICON_EYEBALL", "mfi_graphics/thing/THING_ICON_EYEBALL.png")

gfx.thing_icon_feather = dsb_get_bitmap("THING_ICON_FEATHER", "mfi_graphics/thing/THING_ICON_FEATHER.png")
gfx.thing_dungeon_feather = dsb_get_bitmap("THING_DUNGEON_FEATHER", "mfi_graphics/thing/THING_DUNGEON_FEATHER.png")

gfx.thing_icon_fruit = dsb_get_bitmap("THING_ICON_FRUIT", "mfi_graphics/thing/THING_ICON_FRUIT.png")
gfx.thing_dungeon_fruit = dsb_get_bitmap("THING_DUNGEON_FRUIT", "mfi_graphics/thing/THING_DUNGEON_FRUIT.png")

gfx.thing_icon_gauntlets = dsb_get_bitmap("THING_ICON_GAUNTLETS", "mfi_graphics/thing/THING_ICON_GAUNTLETS.png")
gfx.thing_dungeon_gauntlets = dsb_get_bitmap("THING_DUNGEON_GAUNTLETS", "mfi_graphics/thing/THING_DUNGEON_GAUNTLETS.png")

-- Gem graphics grouped together for convenience
gfx.thing_icon_emerald = dsb_get_bitmap("THING_ICON_EMERALD", "mfi_graphics/thing/THING_ICON_EMERALD.png")
gfx.thing_icon_ruby = dsb_get_bitmap("THING_ICON_RUBY", "mfi_graphics/thing/THING_ICON_RUBY.png")
gfx.thing_icon_sapphire = dsb_get_bitmap("THING_ICON_SAPPHIRE", "mfi_graphics/thing/THING_ICON_SAPPHIRE.png")
gfx.thing_icon_tourmaline = dsb_get_bitmap("THING_ICON_TOURMALINE", "mfi_graphics/thing/THING_ICON_TOURMALINE.png")
gfx.thing_dungeon_gem_yellow = dsb_get_bitmap("THING_DUNGEON_GEM_YELLOW", "mfi_graphics/thing/THING_DUNGEON_GEM_YELLOW.png")

gfx.thing_icon_halberd = dsb_get_bitmap("THING_ICON_HALBERD", "mfi_graphics/thing/THING_ICON_HALBERD.png")
gfx.thing_dungeon_halberd = dsb_get_bitmap("THING_DUNGEON_HALBERD", "mfi_graphics/thing/THING_DUNGEON_HALBERD.png")

gfx.thing_icon_hammer = dsb_get_bitmap("THING_ICON_HAMMER", "mfi_graphics/thing/THING_ICON_HAMMER.png")
gfx.thing_dungeon_hammer = dsb_get_bitmap("THING_DUNGEON_HAMMER", "mfi_graphics/thing/THING_DUNGEON_HAMMER.png")
gfx.thing_dungeon_hammer_away = dsb_get_bitmap("THING_DUNGEON_HAMMER_AWAY", "mfi_graphics/thing/THING_DUNGEON_HAMMER_AWAY.png")
gfx.thing_dungeon_hammer_towards = dsb_get_bitmap("THING_DUNGEON_HAMMER_TOWARDS", "mfi_graphics/thing/THING_DUNGEON_HAMMER_TOWARDS.png")

gfx.thing_icon_hat = dsb_get_bitmap("THING_ICON_HAT", "mfi_graphics/thing/THING_ICON_HAT.png")
gfx.thing_dungeon_hat = dsb_get_bitmap("THING_DUNGEON_HAT", "mfi_graphics/thing/THING_DUNGEON_HAT.png")

gfx.thing_icon_heart = dsb_get_bitmap("THING_ICON_HEART", "mfi_graphics/thing/THING_ICON_HEART.png")
gfx.thing_dungeon_heart = dsb_get_bitmap("THING_DUNGEON_HEART", "mfi_graphics/thing/THING_DUNGEON_HEART.png")

gfx.thing_icon_leather_f = dsb_get_bitmap("THING_ICON_LEATHER_F", "mfi_graphics/thing/THING_ICON_LEATHER_F.png")
gfx.thing_icon_leather_legs_f = dsb_get_bitmap("THING_ICON_LEATHER_LEGS_F", "mfi_graphics/thing/THING_ICON_LEATHER_LEGS_F.png")

gfx.thing_icon_mirrorshield = dsb_get_bitmap("THING_ICON_MIRRORSHIELD", "mfi_graphics/thing/THING_ICON_MIRRORSHIELD.png")
gfx.thing_dungeon_mirrorshield = dsb_get_bitmap("THING_DUNGEON_MIRRORSHIELD", "mfi_graphics/thing/THING_DUNGEON_MIRRORSHIELD.png")

gfx.thing_icon_pernach = dsb_get_bitmap("THING_ICON_PERNACH", "mfi_graphics/thing/THING_ICON_PERNACH.png")

gfx.thing_icon_petrified = dsb_get_bitmap("THING_ICON_PETRIFIED", "mfi_graphics/thing/THING_ICON_PETRIFIED.png")
gfx.thing_dungeon_petrified = dsb_get_bitmap("THING_DUNGEON_PETRIFIED", "mfi_graphics/thing/THING_DUNGEON_PETRIFIED.png")

gfx.thing_icon_razor = dsb_get_bitmap("THING_ICON_RAZOR", "mfi_graphics/thing/THING_ICON_RAZOR.png")

gfx.thing_icon_spear = dsb_get_bitmap("THING_ICON_SPEAR", "mfi_graphics/thing/THING_ICON_SPEAR.png")
gfx.thing_dungeon_spear = dsb_get_bitmap("THING_DUNGEON_SPEAR", "mfi_graphics/thing/THING_DUNGEON_SPEAR.png")
gfx.thing_dungeon_spear_away = dsb_get_bitmap("THING_DUNGEON_SPEAR_AWAY", "mfi_graphics/thing/THING_DUNGEON_SPEAR_AWAY.png")
gfx.thing_dungeon_spear_towards = dsb_get_bitmap("THING_DUNGEON_SPEAR_TOWARDS", "mfi_graphics/thing/THING_DUNGEON_SPEAR_TOWARDS.png")

gfx.thing_icon_trident = dsb_get_bitmap("THING_ICON_TRIDENT", "mfi_graphics/thing/THING_ICON_TRIDENT.png")
gfx.thing_dungeon_trident = dsb_get_bitmap("THING_DUNGEON_TRIDENT", "mfi_graphics/thing/THING_DUNGEON_TRIDENT.png")

-- Armour of Night graphics grouped together for convenience
gfx.thing_icon_breastplate_black = dsb_get_bitmap("THING_ICON_BREASTPLATE_BLACK", "mfi_graphics/thing/THING_ICON_BREASTPLATE_BLACK.png")
gfx.thing_icon_poleyn_black = dsb_get_bitmap("THING_ICON_POLEYN_BLACK", "mfi_graphics/thing/THING_ICON_POLEYN_BLACK.png")
gfx.thing_icon_sabatons_black = dsb_get_bitmap("THING_ICON_SABATONS_BLACK", "mfi_graphics/thing/THING_ICON_SABATONS_BLACK.png")
gfx.thing_icon_armet_black = dsb_get_bitmap("THING_ICON_ARMET_BLACK", "mfi_graphics/thing/THING_ICON_ARMET_BLACK.png")

-- ****************************
-- * DOORS, KEYS AND KEYHOLES *
-- ****************************
gfx.door_brass = dsb_get_bitmap("DOOR_BRASS", "mfi_graphics/door/DOOR_BRASS.png")
gfx.door_glass = dsb_get_bitmap("DOOR_GLASS", "mfi_graphics/door/DOOR_GLASS.png")
gfx.door_ornate = dsb_get_bitmap("DOOR_ORNATE", "mfi_graphics/door/DOOR_ORNATE.png")

gfx.thing_icon_key_brass = dsb_get_bitmap("THING_ICON_KEY_BRASS", "mfi_graphics/thing/THING_ICON_KEY_BRASS.png")
gfx.thing_icon_key_flower = dsb_get_bitmap("THING_ICON_KEY_FLOWER", "mfi_graphics/thing/THING_ICON_KEY_FLOWER.png")
gfx.thing_icon_key_red = dsb_get_bitmap("THING_ICON_KEY_RED", "mfi_graphics/thing/THING_ICON_KEY_RED.png")

gfx.wallitem_keyhole_brass_front = dsb_get_bitmap("WALLITEM_KEYHOLE_BRASS_FRONT", "mfi_graphics/wallitem/WALLITEM_KEYHOLE_BRASS_FRONT.png")
gfx.wallitem_keyhole_brass_side = dsb_get_bitmap("WALLITEM_KEYHOLE_BRASS_SIDE", "mfi_graphics/wallitem/WALLITEM_KEYHOLE_BRASS_SIDE.png")
gfx.wallitem_keyhole_brass_side.x_off = -20

gfx.wallitem_keyhole_flower_front = dsb_get_bitmap("WALLITEM_KEYHOLE_FLOWER_FRONT", "mfi_graphics/wallitem/WALLITEM_KEYHOLE_FLOWER_FRONT.png")
gfx.wallitem_keyhole_flower_side = dsb_get_bitmap("WALLITEM_KEYHOLE_FLOWER_SIDE", "mfi_graphics/wallitem/WALLITEM_KEYHOLE_FLOWER_SIDE.png")
gfx.wallitem_keyhole_flower_side.x_off = -10

gfx.wallitem_keyhole_red_front = dsb_get_bitmap("WALLITEM_KEYHOLE_RED_FRONT", "mfi_graphics/wallitem/WALLITEM_KEYHOLE_RED_FRONT.png")
gfx.wallitem_keyhole_red_side = dsb_get_bitmap("WALLITEM_KEYHOLE_RED_SIDE", "mfi_graphics/wallitem/WALLITEM_KEYHOLE_RED_SIDE.png")
gfx.wallitem_keyhole_red_side.x_off = -22

-- *************
-- * WALLITEMS *
-- *************
gfx.wallitem_altar_front = dsb_get_bitmap("WALLITEM_ALTAR_FRONT", "mfi_graphics/wallitem/WALLITEM_ALTAR_FRONT.png")
gfx.wallitem_altar_front.y_off = -54
gfx.wallitem_altar_side = dsb_get_bitmap("WALLITEM_ALTAR_SIDE", "mfi_graphics/wallitem/WALLITEM_ALTAR_SIDE.png")
gfx.wallitem_altar_side.y_off = -54

gfx.wallitem_banner_front = dsb_get_bitmap("WALLITEM_BANNER_FRONT", "mfi_graphics/wallitem/WALLITEM_BANNER_FRONT.png")
gfx.wallitem_banner_front.y_off = -36
gfx.wallitem_banner_side = dsb_get_bitmap("WALLITEM_BANNER_SIDE", "mfi_graphics/wallitem/WALLITEM_BANNER_SIDE.png")
gfx.wallitem_banner_side.x_off = -12
gfx.wallitem_banner_side.y_off = -28

gfx.wallitem_banner1_front = dsb_get_bitmap("WALLITEM_BANNER1_FRONT", "mfi_graphics/wallitem/WALLITEM_BANNER1_FRONT.png")
gfx.wallitem_banner1_front.y_off = -36
gfx.wallitem_banner1_side = dsb_get_bitmap("WALLITEM_BANNER1_SIDE", "mfi_graphics/wallitem/WALLITEM_BANNER1_SIDE.png")
gfx.wallitem_banner1_side.x_off = -12
gfx.wallitem_banner1_side.y_off = -28

gfx.wallitem_collapse_front = dsb_get_bitmap("WALLITEM_COLLAPSE_FRONT", "mfi_graphics/wallitem/WALLITEM_COLLAPSE_FRONT.png")
gfx.wallitem_collapse_front.y_off = -54
gfx.wallitem_collapse_side = dsb_get_bitmap("WALLITEM_COLLAPSE_SIDE", "mfi_graphics/wallitem/WALLITEM_COLLAPSE_SIDE.png")
gfx.wallitem_collapse_side.y_off = -54

gfx.wallitem_cross_front = dsb_get_bitmap("WALLITEM_CROSS_FRONT", "mfi_graphics/wallitem/WALLITEM_CROSS_FRONT.png")
gfx.wallitem_cross_front.y_off = -54
-- NB. No side view for the cross so it has to have a solid wall on either side if you want to use it without it looking weird.

gfx.wallitem_deerskull_front = dsb_get_bitmap("WALLITEM_DEERSKULL_FRONT", "mfi_graphics/wallitem/WALLITEM_DEERSKULL_FRONT.png")
gfx.wallitem_deerskull_front.y_off = -25
gfx.wallitem_deerskull_side = dsb_get_bitmap("WALLITEM_DEERSKULL_SIDE", "mfi_graphics/wallitem/WALLITEM_DEERSKULL_SIDE.png")
gfx.wallitem_deerskull_side.x_off = -8
gfx.wallitem_deerskull_side.y_off = -25

gfx.wallitem_hanged_front = dsb_get_bitmap("WALLITEM_HANGED_FRONT", "mfi_graphics/wallitem/WALLITEM_HANGED_FRONT.png")
gfx.wallitem_hanged_front.y_off = -60
gfx.wallitem_hanged_side = dsb_get_bitmap("WALLITEM_HANGED_SIDE", "mfi_graphics/wallitem/WALLITEM_HANGED_SIDE.png")
gfx.wallitem_hanged_side.y_off = -54

gfx.wallitem_painting_front_f = dsb_get_bitmap("WALLITEM_PAINTING_FRONT_F", "mfi_graphics/wallitem/WALLITEM_PAINTING_FRONT_F.png")
gfx.wallitem_painting_front_m = dsb_get_bitmap("WALLITEM_PAINTING_FRONT_M", "mfi_graphics/wallitem/WALLITEM_PAINTING_FRONT_M.png")
gfx.wallitem_painting_side = dsb_get_bitmap("WALLITEM_PAINTING_SIDE", "mfi_graphics/wallitem/WALLITEM_PAINTING_SIDE.png")
gfx.wallitem_painting_side.x_off = -20
gfx.wallitem_painting_side.y_off = -4

gfx.wallitem_petrif_front = dsb_get_bitmap("WALLITEM_PETRIF_FRONT", "mfi_graphics/wallitem/WALLITEM_PETRIF_FRONT.png")
gfx.wallitem_petrif_side = dsb_get_bitmap("WALLITEM_PETRIF_SIDE", "mfi_graphics/wallitem/WALLITEM_PETRIF_SIDE.png")
gfx.wallitem_petrif_side.x_off = -12
gfx.wallitem_petrif_side.y_off = -2

gfx.wallitem_skeleton_front = dsb_get_bitmap("WALLITEM_SKELETON_FRONT", "mfi_graphics/wallitem/WALLITEM_SKELETON_FRONT.png")
gfx.wallitem_skeleton_front.y_off = -36
gfx.wallitem_skeleton_side = dsb_get_bitmap("WALLITEM_SKELETON_SIDE", "mfi_graphics/wallitem/WALLITEM_SKELETON_SIDE.png")
gfx.wallitem_skeleton_side.y_off = -54

gfx.wallitem_skull_front = dsb_get_bitmap("WALLITEM_SKULL_FRONT", "mfi_graphics/wallitem/WALLITEM_SKULL_FRONT.png")
gfx.wallitem_skull_front.y_off = -36
-- NB. No side view for the skull so it has to have a solid wall on either side if you want to use it without it looking weird.

gfx.wallitem_statue_front = dsb_get_bitmap("WALLITEM_STATUE_FRONT", "mfi_graphics/wallitem/WALLITEM_STATUE_FRONT.png")
gfx.wallitem_statue_front.y_off = -54
gfx.wallitem_statue_side = dsb_get_bitmap("WALLITEM_STATUE_SIDE", "mfi_graphics/wallitem/WALLITEM_STATUE_SIDE.png")
gfx.wallitem_statue_side.y_off = -54

gfx.wallitem_sunpainting_front = dsb_get_bitmap("WALLITEM_SUNPAINTING_FRONT", "mfi_graphics/wallitem/WALLITEM_SUNPAINTING_FRONT.png")
gfx.wallitem_sunpainting_front.y_off = -20
gfx.wallitem_sunpainting_side = dsb_get_bitmap("WALLITEM_SUNPAINTING_SIDE", "mfi_graphics/wallitem/WALLITEM_SUNPAINTING_SIDE.png")
gfx.wallitem_sunpainting_side.x_off = -12
gfx.wallitem_sunpainting_side.y_off = -16

gfx.wallitem_swords_front = dsb_get_bitmap("WALLITEM_SWORDS_FRONT", "mfi_graphics/wallitem/WALLITEM_SWORDS_FRONT.png")
gfx.wallitem_swords_side = dsb_get_bitmap("WALLITEM_SWORDS_SIDE", "mfi_graphics/wallitem/WALLITEM_SWORDS_SIDE.png")
gfx.wallitem_swords_side.x_off = -10
gfx.wallitem_swords_side.y_off = -12

gfx.wallitem_tapestry_front = dsb_get_bitmap("WALLITEM_TAPESTRY_FRONT", "mfi_graphics/wallitem/WALLITEM_TAPESTRY_FRONT.png")
gfx.wallitem_tapestry_front.y_off = -20
gfx.wallitem_tapestry_side = dsb_get_bitmap("WALLITEM_TAPESTRY_SIDE", "mfi_graphics/wallitem/WALLITEM_TAPESTRY_SIDE.png")
gfx.wallitem_tapestry_side.x_off = -12
gfx.wallitem_tapestry_side.y_off = -24

-- **************
-- * FLOORITEMS *
-- **************
gfx.floorflat_statue = dsb_get_bitmap("FLOORFLAT_STATUE", "mfi_graphics/floorflat/FLOORFLAT_STATUE.png")
gfx.floorflat_statue.y_off = 20

gfx.floorflat_statue_2 = dsb_get_bitmap("FLOORFLAT_STATUE_2", "mfi_graphics/floorflat/FLOORFLAT_STATUE_2.png")
gfx.floorflat_statue_2.y_off = 20

gfx.floorflat_statue_3 = dsb_get_bitmap("FLOORFLAT_STATUE_3", "mfi_graphics/floorflat/FLOORFLAT_STATUE_3.png")
gfx.floorflat_statue_3.y_off = 20

gfx.floorflat_statue_4 = dsb_get_bitmap("FLOORFLAT_STATUE_4", "mfi_graphics/floorflat/FLOORFLAT_STATUE_4.png")
gfx.floorflat_statue_4.y_off = 20

gfx.floorflat_minostatue = dsb_get_bitmap("FLOORFLAT_MINOSTATUE", "mfi_graphics/floorflat/FLOORFLAT_MINOSTATUE.png")
gfx.floorflat_minostatue.y_off = 20

gfx.floorflat_chandelier = dsb_get_bitmap("FLOORFLAT_CHANDELIER", "mfi_graphics/floorflat/FLOORFLAT_CHANDELIER.png")
gfx.floorflat_chandelier.y_off = -136

gfx.floorflat_corpsecage = dsb_get_bitmap("FLOORFLAT_CORPSECAGE", "mfi_graphics/floorflat/FLOORFLAT_CORPSECAGE.png")
gfx.floorflat_corpsecage.y_off = -136

-- **********************************
-- * CHAMPIONS AND CHAMPION HOLDERS *
-- **********************************
gfx.champion_prisoner_yvonne = dsb_get_bitmap("CHAMPION_PRISONER_YVONNE", "mfi_graphics/champion/CHAMPION_PRISONER_YVONNE.png")
gfx.champion_prisoner_wort = dsb_get_bitmap("CHAMPION_PRISONER_WORT", "mfi_graphics/champion/CHAMPION_PRISONER_WORT.png")
gfx.champion_prisoner_wort.y_off = -60
gfx.champion_prisoner_helen = dsb_get_bitmap("CHAMPION_PRISONER_HELEN", "mfi_graphics/champion/CHAMPION_PRISONER_HELEN.png")
gfx.champion_prisoner_helen.y_off = -60
gfx.champion_portrait_yvonne = dsb_get_bitmap("CHAMPION_PORTRAIT_YVONNE", "mfi_graphics/champion/CHAMPION_PORTRAIT_YVONNE.png")
gfx.champion_portrait_wort = dsb_get_bitmap("CHAMPION_PORTRAIT_WORT", "mfi_graphics/champion/CHAMPION_PORTRAIT_WORT.png")
gfx.champion_portrait_helen = dsb_get_bitmap("CHAMPION_PORTRAIT_HELEN2", "mfi_graphics/champion/CHAMPION_PORTRAIT_HELEN.png")

-- ********
-- * MISC *
-- ********
gfx.misc_mindblast = dsb_get_bitmap("MISC_MINDBLAST", "mfi_graphics/misc/MISC_MINDBLAST.png")
gfx.water_overlay = dsb_get_bitmap("WATER_OVERLAY", "mfi_graphics/misc/MISC_WATER_OVERLAY.png")
gfx.top_dead_petrified = dsb_get_bitmap("TOP_DEAD_PETRIFIED", "mfi_graphics/misc/MISC_TOP_DEAD_PETRIFIED.png")