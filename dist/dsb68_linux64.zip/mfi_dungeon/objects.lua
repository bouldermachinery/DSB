-- ************
-- * MONSTERS *
-- ************
obj.ant = {
    name="ANT",
	type="MONSTER",
	class="BEAST",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_ant_front,
	side=gfx.monster_ant_side,
	back=gfx.monster_ant_back,
	attack=gfx.monster_ant_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=25,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_scuffle,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.banshee = {
    name="BANSHEE",
	type="MONSTER",
	class="NONMAT",
	size=1,
	col=nonmat_col,
	no_bump=true,
  	nonmat=true,
	hover=true,
	hp=50,
	front=gfx.monster_banshee_front,
	side=gfx.monster_banshee_side,
	back=gfx.monster_banshee_back,
	attack=gfx.monster_banshee_attack,
	hover=true,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=50,
	base_power=20,
	armor=25,
	anti_fire=999,
	anti_poison=999,
	anti_desew=50,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_scuffle,
	attack_sound=snd.undead,
	attack_type=ATTACK_WISDOM,
	attack_zonetable=ZT_TORSO_GHOST,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.basilisk = {
    name="BASILISK",
	type="MONSTER",
	class="BEAST",
	size=2,
	col=true,
	no_bump=true,
	hp=125,
	front=gfx.monster_basilisk_front,
	side=gfx.monster_basilisk_side,
	back=gfx.monster_basilisk_back,
	attack=gfx.monster_basilisk_attack,
	perception=4,
	awareness=2,
	bravery=30,
	act_rate=17,
	attack_delay=10,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=55,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.roar,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_HEAD_OR_TORSO_LOW,
	special_attack = petrif_special_attack,
	special_chance = 80,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.beholder = {
    name="BEHOLDER",
        type="MONSTER",
        class="FLYING",
        group_type=GT_FAST_FLYERS, 
        size=4,
        col=true,
        no_bump=true,
        hover=true,
        no_stopclicks=true,
        smart=true,
        crafty=true,
        hp=100,
        front=gfx.monster_beholder_front,
        side=gfx.monster_beholder_side,
        back=gfx.monster_beholder_back,
        attack=gfx.monster_beholder_attack,
        perception=4,
        awareness=4,
        bravery=15,
        act_rate=2,
        attack_delay=10,
	shift_rate=9,
        flip_rate=3,
        quickness=150,
        base_power=200,
        poison=10,
        armor=180,
        anti_fire=50,
        anti_poison=60,
        anti_desew=999,
        xp_factor=9,
        msg_handler=monster_msg_handler,
        on_move=monster_step,
        on_attack_close=monster_attack,
	on_attack_ranged=monster_missile,
	missile_power=120,
	should_attack_ranged=halfranged,
	missile_type="lightning",
	door_opener="zospell",
	door_breaker="lightning",
	on_incoming_impact=monster_dodge,
	on_shot_missile_impact=zo_success_check,
      	on_die=setup_item_drop,
    	drop_item_type={ "eyeball" },
        step_sound=snd.step_flying,
        attack_type=ATTACK_PHYSICAL,
        attack_zonetable=ZT_HEAD,
        hit_height=24,
        death_size=16,
        death_delta=2,
        proj_stick=10
}

obj.bonenaga = {
    name="BONENAGA",
	type="MONSTER",
	class="UNDEAD",
	size=4,
	col=true,
	no_bump=true,
	hp=90,
	front=gfx.monster_bonenaga_front,
	side=gfx.monster_bonenaga_side,
	back=gfx.monster_bonenaga_back,
	attack=gfx.monster_bonenaga_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=15,
	shift_rate=19,
	quickness=60,
	base_power=100,
	armor=60,
	anti_fire=55,
	anti_poison=999,
	anti_desew=999,
	xp_factor=10,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.slither,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_TORSO_SCORPION,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.bugbear = {
    name="BUGBEAR",
	type="MONSTER",
	class="HUMANOID",
	size=4,
	col=true,
	no_bump=true,
	crafty=true,
	smart=true,
	pounces=true,
	counterattack=true,
	hp=75,
	front=gfx.monster_bugbear_front,
	side=gfx.monster_bugbear_side,
	back=gfx.monster_bugbear_back,
	attack=gfx.monster_bugbear_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=6,
	attack_delay=1,
	shift_rate=19,
	quickness=60,
	base_power=33,
	armor=25,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	on_die=setup_item_drop,
	drop_item_type={ "axe" },
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_TORSO,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.carrioncrawler = {
    name="CARRIONCRAWLER",
	type="MONSTER",
	class="BEAST",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_carrioncrawler_front,
	side=gfx.monster_carrioncrawler_side,
	back=gfx.monster_carrioncrawler_back,
	attack=gfx.monster_carrioncrawler_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=70,
	base_power=20,
	armor=25,
	anti_fire=40,
	anti_poison=65,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_scuffle,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_HEAD_OR_TORSO_LOW,
	attack_show_duration=4,
	special_attack = ghoul_special_attack,
	special_chance = 50,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.cerberus = {
    name="CERBERUS",
	type="MONSTER",
	class="BEAST",
	size=4,
	col=true,
	no_bump=true,
	hp=150,
	front=gfx.monster_cerberus_front,
	side=gfx.monster_cerberus_side,
	back=gfx.monster_cerberus_back,
	attack=gfx.monster_cerberus_attack,
	perception=4,
	awareness=2,
	bravery=12,
	act_rate=17,
	attack_delay=40,
	shift_rate=19,
	quickness=40,
	base_power=80,
	armor=45,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.roar,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_HEAD_OR_TORSO_LOW,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.chimera = {
    name="CHIMERA",
	type="MONSTER",
	class="BEAST",
	size=4,
	col=true,
	no_bump=true,
	hp=60,
	front=gfx.monster_chimera_front,
	side=gfx.monster_chimera_side,
	back=gfx.monster_chimera_back,
	attack=gfx.monster_chimera_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=35,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
        msg_handler=monster_msg_handler,
        on_move=monster_step,
        on_attack_close=monster_attack,
	on_attack_ranged=monster_missile,
	missile_power=120,
	should_attack_ranged=halfranged,
	missile_type="fireball",
	door_breaker="fireball",
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.roar,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.cockatrice = {
        name="COCKATRICE",
        type="MONSTER",
        class="FLYING",
        group_type=GT_FAST_FLYERS,
        size=1,
        col=true,
        no_bump=true,
        hover=true,
        no_stopclicks=true,
        crafty=true,
        hp=50,
        front=gfx.monster_cockatrice_front,
        side=gfx.monster_cockatrice_side,
        back=gfx.monster_cockatrice_back,
        attack=gfx.monster_cockatrice_attack,
        perception=2,
        awareness=4,
        bravery=15,
        act_rate=2,
        attack_delay=10,
 	shift_rate=9,
        flip_rate=3,
        quickness=150,
        base_power=20,
        poison=10,
        armor=180,
        anti_fire=8,
        anti_poison=4,
        anti_desew=999,
        xp_factor=9,
        msg_handler=monster_msg_handler,
        on_move=monster_step,
   	on_attack_close=monster_attack,
   	on_incoming_impact=monster_dodge,
        step_sound=snd.step_flying,
        attack_type=ATTACK_PIERCING,
        attack_zonetable=ZT_HEAD,
	special_attack = petrif_special_attack,
	special_chance = 70,
        hit_height=24,
        death_size=16,
        death_delta=2,
        proj_stick=10
}

obj.crab = {
    name="CRAB",
	type="MONSTER",
	class="BEAST",
	size=4,
	col=true,
	no_bump=true,
	hp=50,
	front=gfx.monster_crab_front,
	side=gfx.monster_crab_side,
	back=gfx.monster_crab_side,
	attack=gfx.monster_crab_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=50,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_scuffle,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.deathknight = {
    name="DEATHKNIGHT",
	type="MONSTER",
	class="UNDEAD",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_deathknight_front,
	side=gfx.monster_deathknight_side,
	back=gfx.monster_deathknight_back,
	attack=gfx.monster_deathknight_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=100,
	anti_fire=20,
	anti_poison=999,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_HEAD,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.ettin = {
    name="ETTIN",
	type="MONSTER",
	class="HUMANOID",
	size=4,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_ettin_front,
	side=gfx.monster_ettin_side,
	back=gfx.monster_ettin_back,
	attack=gfx.monster_ettin_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=45,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	on_die=setup_item_drop,
	drop_item_type={ "club" },
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.feyr = {
    name="FEYR",
	type="MONSTER",
	class="BEAST",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_feyr_front,
	side=gfx.monster_feyr_side,
	back=gfx.monster_feyr_back,
	attack=gfx.monster_feyr_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=50,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.fish = {
    name="FISH",
	type="MONSTER",
	class="BEAST",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	hover=true,
	front=gfx.monster_fish_front,
	side=gfx.monster_fish_side,
	back=gfx.monster_fish_back,
	attack=gfx.monster_fish_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=50,
	quickness=40,
	base_power=20,
	armor=25,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	attack_sound=snd.monster_wetattack,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_TORSO,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}
obj.gargoyle = {
    name="GARGOYLE",
	type="MONSTER",
	class="BEAST",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_gargoyle_front,
	side=gfx.monster_gargoyle_side,
	back=gfx.monster_gargoyle_back,
	attack=gfx.monster_gargoyle_attack,
	perception=4,
	awareness=3,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=35,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.ghoul = {
    name="GHOUL",
	type="MONSTER",
	class="UNDEAD",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_ghoul_front,
	side=gfx.monster_ghoul_side,
	back=gfx.monster_ghoul_back,
	attack=gfx.monster_ghoul_attack,
	perception=4,
	awareness=2,
	bravery=11,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=25,
	anti_fire=20,
	anti_poison=999,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	special_attack = ghoul_special_attack,
	special_chance = 50,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.gnoll = {
    name="GNOLL",
	type="MONSTER",
	class="HUMANOID",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_gnoll_front,
	side=gfx.monster_gnoll_side,
	back=gfx.monster_gnoll_back,
	attack=gfx.monster_gnoll_attack,
	perception=4,
	awareness=2,
	bravery=8,
	act_rate=17,
	attack_delay=5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=35,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	on_die=setup_item_drop,
	drop_item_type={ "mace" },
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_HEAD,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.goblin = {
    name="GOBLIN",
	type="MONSTER",
	class="HUMANOID",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_goblin_front,
	side=gfx.monster_goblin_side,
	back=gfx.monster_goblin_back,
	attack=gfx.monster_goblin_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=14,
	attack_delay=-5,
	shift_rate=19,
	quickness=50,
	base_power=20,
	armor=20,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	on_die=setup_item_drop,
	drop_item_type={ "helmet" },
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.guardian = {
    name="GUARDIAN",
	type="MONSTER",
	class="BEAST",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_guardian_front,
	side=gfx.monster_guardian_side,
	back=gfx.monster_guardian_back,
	attack=gfx.monster_guardian_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=70,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.harpy = {
    name="HARPY",
	type="MONSTER",
	class="FLYING",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	hover=true,
	crafty=true,
	front=gfx.monster_harpy_front,
	side=gfx.monster_harpy_side,
	back=gfx.monster_harpy_back,
	attack=gfx.monster_harpy_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=50,
	quickness=40,
	base_power=20,
	armor=25,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_flying,
	attack_sound=snd.roar,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_TORSO,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.hobgoblin = {
    name="HOBGOBLIN",
	type="MONSTER",
	class="HUMANOID",
	size=1,
	col=true,
	no_bump=true,
	crafty=true,
	smart=true,
	hp=40,
	front=gfx.monster_hobgoblin_front,
	side=gfx.monster_hobgoblin_side,
	back=gfx.monster_hobgoblin_back,
	attack=gfx.monster_hobgoblin_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=9,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=30,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	on_die=setup_item_drop,
	drop_item_type={ "club" },
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.kobold = {
    name="KOBOLD",
	type="MONSTER",
	class="HUMANOID",
	size=1,
	col=true,
	no_bump=true,
	hp=20,
	front=gfx.monster_kobold_front,
	side=gfx.monster_kobold_side,
	back=gfx.monster_kobold_back,
	attack=gfx.monster_kobold_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=15,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	on_die=setup_item_drop,
	drop_item_type={ "dagger" },
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.leech = {
    name="LEECH",
	type="MONSTER",
	class="BEAST",
	size=1,
	col=true,
	no_bump=true,
	hp=25,
	front=gfx.monster_leech_front,
	side=gfx.monster_leech_side,
	back=gfx.monster_leech_back,
	attack=gfx.monster_leech_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=10,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.slither,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.lizardman = {
    name="LIZARDMAN",
	type="MONSTER",
	class="HUMANOID",
	size=1,
	col=true,
	no_bump=true,
	crafty=true,
	hp=50,
	front=gfx.monster_lizardman_front,
	side=gfx.monster_lizardman_side,
	back=gfx.monster_lizardman_back,
	attack=gfx.monster_lizardman_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=7,
	attack_delay=-5,
	shift_rate=19,
	quickness=80,
	base_power=20,
	armor=25,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	on_die=setup_item_drop,
	drop_item_type={ "spear" },
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.medusa_snake = {
    name="MEDUSA_SNAKE",
	type="MONSTER",
	class="BEAST",
	size=2,
	col=true,
	no_bump=true,
	hp=60,
	front=gfx.monster_medusa_snake_front,
	side=gfx.monster_medusa_snake_side,
	back=gfx.monster_medusa_snake_back,
	attack=gfx.monster_medusa_snake_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=65,
	anti_fire=20,
	anti_poison=75,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.slither,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.medusa_woman = {
    name="MEDUSA_WOMAN",
	type="MONSTER",
	class="HUMANOID",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_medusa_woman_front,
	side=gfx.monster_medusa_woman_side,
	back=gfx.monster_medusa_woman_back,
	attack=gfx.monster_medusa_woman_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=25,
	anti_fire=75,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.mindflayer = {
    name="MINDFLAYER",
	type="MONSTER",
	class="BEAST",
	size=1,
	col=true,
	no_bump=true,
	smart=true,
	crafty=true,
	hp=50,
	front=gfx.monster_mindflayer_front,
	side=gfx.monster_mindflayer_side,
	back=gfx.monster_mindflayer_back,
	attack=gfx.monster_mindflayer_attack,
	perception=4,
	awareness=3,
	bravery=12,
	act_rate=10,
	attack_delay=4,
	shift_rate=12,
	quickness=90,
	base_power=100,
	armor=25,
	anti_fire=999,
	anti_poison=999,
	anti_desew=999,
	xp_factor=15,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_attack_ranged=monster_missile,
	missile_power=200,
	should_attack_ranged=halfranged,
	missile_type="mindblast",
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	special_attack=mindflayer_touch,
	special_chance=90,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.minotaur = {
    name="MINOTAUR",
	type="MONSTER",
	class="BEAST",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_minotaur_front,
	side=gfx.monster_minotaur_side,
	back=gfx.monster_minotaur_back,
	attack=gfx.monster_minotaur_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=85,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.mudman = {
    name="MUDMAN",
	type="MONSTER",
	class="HUMANOID",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_mudman_front,
	side=gfx.monster_mudman_side,
	back=gfx.monster_mudman_back,
	attack=gfx.monster_mudman_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=1,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=25,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_wet,
	attack_sound=snd.splash,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.ogreslug = {
    name="OGRE SLUG",
	type="MONSTER",
	class="BEAST",
	size=4,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_ogreslug_front,
	side=gfx.monster_ogreslug_side,
	back=gfx.monster_ogreslug_back,
	attack=gfx.monster_ogreslug_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=40,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.orc = {
    name="ORC",
	type="MONSTER",
	class="HUMANOID",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_orc_front,
	side=gfx.monster_orc_side,
	back=gfx.monster_orc_back,
	attack=gfx.monster_orc_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=11,
	attack_delay=1,
	shift_rate=19,
	quickness=60,
	base_power=20,
	armor=25,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	on_die=setup_item_drop,
	drop_item_type={ "falchion" },
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.otyugh = {
    name="OTYUGH",
	type="MONSTER",
	class="BEAST",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_otyugh_front,
	side=gfx.monster_otyugh_side,
	back=gfx.monster_otyugh_back,
	attack=gfx.monster_otyugh_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=25,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_scuffle,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.poltergeist = {
    name="POLTERGEIST",
	type="MONSTER",
	class="NONMAT",
	size=1,
	col=nonmat_col,
	no_bump=true,
  	nonmat=true,
	hp=33,
	front=gfx.monster_poltergeist_front,
	side=gfx.monster_poltergeist_side,
	back=gfx.monster_poltergeist_back,
	attack=gfx.monster_poltergeist_attack,
	hover=true,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=25,
	anti_fire=999,
	anti_poison=999,
	anti_desew=50,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.undead,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_TORSO,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.seaspirit = {
    name="SEA SPIRIT",
	type="MONSTER",
	class="NONMAT",
	size=1,
	col=nonmat_col,
	no_bump=true,
  	nonmat=true,
	hp=33,
	front=gfx.monster_seaspirit_front,
	side=gfx.monster_seaspirit_side,
	back=gfx.monster_seaspirit_back,
	attack=gfx.monster_seaspirit_attack,
	hover=true,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=15,
	shift_rate=22,
	quickness=65,
	base_power=30,
	armor=30,
	anti_fire=20,
	anti_poison=999,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_wet,
	attack_sound=snd.splash,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_TORSO,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.shadow = {
    name="SHADOW",
	type="MONSTER",
	class="NONMAT",
	size=1,
	col=nonmat_col,
	no_bump=true,
  	nonmat=true,
	hp=33,
	hover=true,
	front=gfx.monster_shadow_front,
	side=gfx.monster_shadow_side,
	back=gfx.monster_shadow_back,
	attack=gfx.monster_shadow_attack,
	hover=true,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=25,
	anti_fire=999,
	anti_poison=999,
	anti_desew=50,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.undead,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_TORSO,
	attack_show_duration=4,
	special_attack = shadow_special_attack,
	special_chance = 40,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.shamblingmound = {
    name="SHADOW",
	type="MONSTER",
	class="BEAST",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_shamblingmound_front,
	side=gfx.monster_shamblingmound_side,
	back=gfx.monster_shamblingmound_back,
	attack=gfx.monster_shamblingmound_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=25,
	anti_fire=999,
	anti_poison=999,
	anti_desew=50,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_wet,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_TORSO,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.skeleton1 = {
    name="SKELETON1",
	type="MONSTER",
	class="UNDEAD",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_skeleton1_front,
	side=gfx.monster_skeleton1_side,
	back=gfx.monster_skeleton1_back,
	attack=gfx.monster_skeleton1_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=45,
	anti_fire=20,
	anti_poison=999,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	on_die=setup_item_drop,
	drop_item_type={ "sabre" },
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_TORSO,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.skeletonwarrior = {
    name="SKELETONWARRIOR",
	type="MONSTER",
	class="UNDEAD",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_skeletonwarrior_front,
	side=gfx.monster_skeletonwarrior_side,
	back=gfx.monster_skeletonwarrior_back,
	attack=gfx.monster_skeletonwarrior_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=75,
	anti_fire=20,
	anti_poison=999,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	on_die=setup_item_drop,
	drop_item_type={ "katana" },
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.sorceror = {
    name="SORCEROR",
	type="MONSTER",
	class="HUMANOID",
	size=1,
	col=true,
	no_bump=true,
    	crafty=true,
	smart=true,
	hp=33,
	front=gfx.monster_sorceror_front,
	side=gfx.monster_sorceror_side,
	back=gfx.monster_sorceror_back,
	attack=gfx.monster_sorceror_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=25,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
        msg_handler=monster_msg_handler,
        on_move=monster_step,
        on_attack_close=monster_attack,
	on_attack_ranged=monster_missile,
	missile_power=80,
	should_attack_ranged=halfranged,
	missile_type="lightning",
	door_opener="zospell",
	door_breaker="lightning",
	on_incoming_impact=monster_dodge,
	on_shot_missile_impact=zo_success_check,
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
   	prefer_ranged=true,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.sorceror1 = clone_arch(obj.sorceror, {
    name="SORCEROR1",
	front=gfx.monster_sorceror1_front,
	side=gfx.monster_sorceror1_front,
	back=gfx.monster_sorceror1_front,
	attack=gfx.monster_sorceror1_attack
} )

obj.spider = {
    name="SPIDER",
	type="MONSTER",
	class="BEAST",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_spider_front,
	side=gfx.monster_spider_side,
	back=gfx.monster_spider_back,
	attack=gfx.monster_spider_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=25,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_scuffle,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.spider_brown = clone_arch(obj.spider, {
    name="SPIDER_BROWN",
	front=gfx.monster_spider_brown_front,
	side=gfx.monster_spider_brown_side,
	back=gfx.monster_spider_brown_back,
	attack=gfx.monster_spider_brown_attack
} )

obj.tree1 = {
    name="TREE1",
	type="MONSTER",
	class="BEAST",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_tree1_front,
	side=gfx.monster_tree1_front,
	back=gfx.monster_tree1_front,
	attack=gfx.monster_tree1_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=25,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	on_die=setup_item_drop,
	drop_item_type={ "berries" },
	step_sound=snd.step_scuffle,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.tree2 = clone_arch(obj.tree1, {
    name="TREE2",
	front=gfx.monster_tree2_front,
	side=gfx.monster_tree2_front,
	back=gfx.monster_tree2_front,
	attack=gfx.monster_tree2_attack,
	drop_item_type={ "fruit" }
} )

obj.tree3 = clone_arch(obj.tree1, {
    name="TREE3",
	front=gfx.monster_tree3_front,
	side=gfx.monster_tree3_front,
	back=gfx.monster_tree3_front,
	attack=gfx.monster_tree3_attack
} )

obj.troll = {
    name="TROLL",
	type="MONSTER",
	class="HUMANOID",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_troll_front,
	side=gfx.monster_troll_side,
	back=gfx.monster_troll_back,
	attack=gfx.monster_troll_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=55,
	anti_fire=20,
	anti_poison=60,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	on_die=setup_item_drop,
	drop_item_type={ "heart" },
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.umberhulk = {
    name="UMBER HULK",
	type="MONSTER",
	class="BEAST",
	size=1,
	col=true,
	pounces=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_umberhulk_front,
	side=gfx.monster_umberhulk_side,
	back=gfx.monster_umberhulk_back,
	attack=gfx.monster_umberhulk_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=75,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.undeadbeast = {
    name="UNDEAD BEAST",
	type="MONSTER",
	class="UNDEAD",
	size=1,
	col=true,
	pounces=true,
	no_bump=true,
	hp=65,
	front=gfx.monster_undeadbeast_front,
	side=gfx.monster_undeadbeast_side,
	back=gfx.monster_undeadbeast_back,
	attack=gfx.monster_undeadbeast_attack,
	perception=4,
	awareness=2,
	bravery=30,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=90,
	armor=65,
	anti_fire=40,
	anti_poison=999,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.waterelemental = {
    name="WATER ELEMENTAL",
	type="MONSTER",
	class="NONMAT",
	size=1,
	col=nonmat_col,
	no_bump=true,
  	nonmat=true,
	hp=100,
	front=gfx.monster_waterelemental_front,
	side=gfx.monster_waterelemental_side,
	back=gfx.monster_waterelemental_back,
	attack=gfx.monster_waterelemental_attack,
	hover=true,
	perception=4,
	awareness=2,
	bravery=17,
	act_rate=17,
	attack_delay=10,
	shift_rate=19,
	quickness=50,
	base_power=80,
	armor=50,
	anti_fire=20,
	anti_poison=999,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_wet,
	attack_sound=snd.splash,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.waterweird = {
    name="WATER WEIRD",
	type="MONSTER",
	class="NONMAT",
	size=1,
	col=nonmat_col,
	no_bump=true,
  	nonmat=true,
	hp=33,
	front=gfx.monster_waterweird_front,
	side=gfx.monster_waterweird_side,
	back=gfx.monster_waterweird_back,
	attack=gfx.monster_waterweird_attack,
	hover=true,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=15,
	shift_rate=22,
	quickness=65,
	base_power=30,
	armor=30,
	anti_fire=20,
	anti_poison=999,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_wet,
	attack_sound=snd.splash,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.wight = {
    name="WIGHT",
	type="MONSTER",
	class="UNDEAD",
	size=1,
	col=true,
	smart=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_wight_front,
	side=gfx.monster_wight_side,
	back=gfx.monster_wight_back,
	attack=gfx.monster_wight_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=25,
	anti_fire=20,
	anti_poison=999,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	special_attack = wight_special_attack,
	special_chance = 50,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.witch = {
    name="WITCH",
	type="MONSTER",
	class="HUMANOID",
	size=1,
	col=true,
	crafty=true,
	smart=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_witch_front,
	side=gfx.monster_witch_side,
	back=gfx.monster_witch_back,
	attack=gfx.monster_witch_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=25,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_TORSO,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.wraith = {
    name="WRAITH",
	type="MONSTER",
	class="NONMAT",
	size=1,
	col=nonmat_col,
	no_bump=true,
  	nonmat=true,
	hp=33,
	front=gfx.monster_wraith_front,
	side=gfx.monster_wraith_side,
	back=gfx.monster_wraith_back,
	attack=gfx.monster_wraith_attack,
	hover=true,
	crafty=true,
	smart=true,
	perception=4,
	awareness=3,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=50,
	base_power=20,
	armor=25,
	anti_fire=999,
	anti_poison=999,
	anti_desew=50,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.undead,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_TORSO,
	attack_show_duration=4,
	special_attack = wraith_special_attack,
	special_chance = 60,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.wyvern = {
    name="WYVERN",
	type="MONSTER",
	class="FLYING",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	hover=true,
	crafty=true,
	front=gfx.monster_wyvern_front,
	side=gfx.monster_wyvern_side,
	back=gfx.monster_wyvern_back,
	attack=gfx.monster_wyvern_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=25,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_flying,
	attack_sound=snd.roar,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_TORSO,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.xorn = {
    name="XORN",
	type="MONSTER",
	class="BEAST",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	crafty=true,
	front=gfx.monster_xorn_front,
	side=gfx.monster_xorn_side,
	back=gfx.monster_xorn_back,
	attack=gfx.monster_xorn_attack,
	perception=4,
	awareness=2,
	bravery=9,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=40,
	base_power=20,
	armor=25,
	anti_fire=20,
	anti_poison=20,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	on_die=setup_item_drop,
	drop_item_type={ "boulder" },
	step_sound=snd.step_scuffle,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_LEGS,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

obj.zombie = {
    name="ZOMBIE",
	type="MONSTER",
	class="UNDEAD",
	size=1,
	col=true,
	no_bump=true,
	hp=33,
	front=gfx.monster_zombie_front,
	side=gfx.monster_zombie_side,
	back=gfx.monster_zombie_back,
	attack=gfx.monster_zombie_attack,
	perception=4,
	awareness=2,
	bravery=10,
	act_rate=17,
	attack_delay=-5,
	shift_rate=19,
	quickness=20,
	base_power=20,
	armor=25,
	anti_fire=20,
	anti_poison=999,
	anti_desew=999,
	xp_factor=4,
	msg_handler=monster_msg_handler,
	on_move=monster_step,
	on_attack_close=monster_attack,
	on_incoming_impact=monster_dodge,
	step_sound=snd.step_footstep,
	attack_sound=snd.swish,
	attack_type=ATTACK_PHYSICAL,
	attack_zonetable=ZT_TORSO,
	attack_show_duration=4,
	hit_height=24,
	death_size=16,
	death_delta=2,
	proj_stick=66
}

-- **********
-- * THINGS *
-- **********
obj.bag = clone_arch(obj.chest, {
	name="BAG",
	mass=35,
	icon=gfx.thing_icon_bag_closed,
	alt_icon=gfx.thing_icon_bag_open,
	dungeon=gfx.thing_dungeon_bag,
	inside_gfx=gfx.thing_subrenderer_bag
} )

obj.berries = {
	name="BERRIES",
	type="THING",
	shortdesc="CONSUMABLE",
	class="FOOD",
	mass=4,
	icon=gfx.thing_icon_berries,
	dungeon=gfx.thing_dungeon_berries,
	foodval=500,
	fit_pouch = true,		
	on_consume=eatdrink
}

obj.book1 = {
    name="BOOK",
	type="THING",
	class="MISC",
	mass=1,
	icon=gfx.thing_icon_book1,
	dungeon=gfx.thing_dungeon_book,
	fit_pouch=true
}

obj.book2 = clone_arch(obj.book1, {
   	icon=gfx.thing_icon_book2
} )

obj.book3 = clone_arch(obj.book1, {
   	icon=gfx.thing_icon_book3
} )

obj.book4 = clone_arch(obj.book1, {
   	icon=gfx.thing_icon_book4
} )

obj.book5 = clone_arch(obj.book1, {
   	icon=gfx.thing_icon_book5
} )

obj.book6 = clone_arch(obj.book1, {
   	icon=gfx.thing_icon_book6
} )

obj.book7 = clone_arch(obj.book1, {
   	icon=gfx.thing_icon_book7
} )

obj.book8 = clone_arch(obj.book1, {
   	icon=gfx.thing_icon_book8
} )

obj.book9 = clone_arch(obj.book1, {
   	icon=gfx.thing_icon_book9
} )

obj.book10 = clone_arch(obj.book1, {
   	icon=gfx.thing_icon_book10
} )

obj.book11 = clone_arch(obj.book1, {
   	icon=gfx.thing_icon_book11
} )

obj.book12 = clone_arch(obj.book1, {
   	icon=gfx.thing_icon_book12
} )

obj.book13 = clone_arch(obj.book1, {
   	icon=gfx.thing_icon_book13
} )

obj.bottle = {
    name="BOTTLE",
	type="THING",
	class="MISC",
	mass=3,
	icon=gfx.thing_icon_bottle,
	dungeon=gfx.thing_dungeon_bottle,
	fit_pouch=true,
	hit_sound=snd.dink
}

obj.brigandine_f = {
	name = "BRIGANDINE",
	type="THING",
	class="TORSO",
	mass = 6,
	icon=gfx.thing_icon_brigandine_f,
	dungeon=gfx.thing_dungeon_brigandine,
	fit_torso=true,
	fit_chest=true,
	armor_str = 17,
	sharp_resist = 3,
	useless_thrown=true
}

obj.brigandine_m = {
	name = "BRIGANDINE",
	type="THING",
	class="TORSO",
	mass = 6,
	icon=gfx.thing_icon_brigandine_m,
	dungeon=gfx.thing_dungeon_brigandine,
	fit_torso=true,
	fit_chest=true,
	armor_str = 17,
	sharp_resist = 3,
	useless_thrown=true
}

obj.brigandine_legs_f = {
	name = "BRIG TREWS",
	type="THING",
	class="LEGS",
	mass = 8,
	icon=gfx.thing_icon_brigandine_legs_f,
	dungeon=gfx.thing_dungeon_brigandine_legs,
	fit_legs=true,
	fit_chest=true,
	armor_str = 20,
	sharp_resist = 3,
	useless_thrown=true
}

obj.brigandine_legs_m = {
	name = "BRIG TREWS",
	type="THING",
	class="LEGS",
	mass = 8,
	icon=gfx.thing_icon_brigandine_legs_m,
	dungeon=gfx.thing_dungeon_brigandine_legs,
	fit_legs=true,
	fit_chest=true,
	armor_str = 20,
	sharp_resist = 3,
	useless_thrown=true
}

obj.chalice = {
    name="CHALICE",
	type="THING",
	class="MISC",
	mass=3,
	icon=gfx.thing_icon_chalice,
	dungeon=gfx.thing_dungeon_chalice,
	fit_pouch=true,
	hit_sound=snd.dink
}

obj.chalice_empty = {
    name="CHALICE",
	type="THING",
	class="MISC",
	mass=3,
	icon=gfx.thing_icon_chalice_empty,
	dungeon=gfx.thing_dungeon_chalice_empty,
	fit_pouch=true,
	hit_sound=snd.dink
}

obj.crown = {
    name="CROWN",
	type="THING",
	class="HEAD",
	mass=14,
	icon=gfx.thing_icon_crown,
	dungeon=gfx.thing_dungeon_crown,
	fit_head = true,
	fit_chest = true,
	armor_str = 17,
	sharp_resist = 5,
	hit_sound=snd.dink
}

obj.decapitator = {
	name="DECAPITATOR",
	type="THING",
	class="WEAPON",
	mass=66,
	icon=gfx.thing_icon_decapitator,
	dungeon=gfx.axe,
	flying_away=gfx.axe_flying,
	flying_toward=gfx.axe_flying,
	flying_side=gfx.axe_flying_side,		
	methods = {
	    { "CHOP", 0, CLASS_FIGHTER, method_physattack },
	    { "HEW", 5, { CLASS_FIGHTER, SKILL_SWINGING }, method_physattack },
	    { "HACK", 6, { CLASS_FIGHTER, SKILL_SWINGING }, method_physattack }
	},	
	base_range=10,
	base_tpower=70,
	impact=35,
	bonus_power=12,
	fit_sheath=true,
	hit_sound=snd.dink
}

obj.dwarfaxe = {
	name="DWARF AXE",
	type="THING",
	class="WEAPON",
	mass=60,
	icon=gfx.thing_icon_dwarfaxe,
	dungeon=gfx.axe,
	flying_away=gfx.axe_flying,
	flying_toward=gfx.axe_flying,
	flying_side=gfx.axe_flying_side,		
	methods = {
	    { "CHOP", 0, CLASS_FIGHTER, method_physattack },
	    { "CLEAVE", 2, { CLASS_FIGHTER, SKILL_SWINGING }, method_physattack },
	    { "HEW", 5, { CLASS_FIGHTER, SKILL_SWINGING }, method_physattack }
	},	
	base_range=10,
	base_tpower=70,
	impact=33,
	bonus_power=6,
	fit_sheath=true,
	hit_sound=snd.dink
}

obj.egg = {
	name="EGG",
	type="THING",
	shortdesc="CONSUMABLE",
	class="FOOD",
	mass=4,
	icon=gfx.thing_icon_egg,
	dungeon=gfx.thing_dungeon_egg,
	foodval=200,
	fit_pouch = true,		
	on_consume=eatdrink
}

obj.emerald = {
    name="EMERALD",
	type="THING",
	class="GEM",
	mass=2,
	icon=gfx.thing_icon_emerald,
	dungeon=gfx.gem_green,
	fit_pouch=true,
	hit_sound=snd.dink
}

obj.eyeball = {
	name="EYEBALL",
	type="THING",
	class = "MISC",
	mass=1,
	icon=gfx.thing_icon_eyeball,
	dungeon=gfx.thing_icon_eyeball,
	fit_pouch=true,
	useless_thrown=true
}

obj.feather = clone_arch(obj.eyeball, {
    name="FEATHER",
    icon=gfx.thing_icon_feather,
    dungeon=gfx.thing_dungeon_feather
} )

obj.fruit = {
	name="ODD FRUIT",
	type="THING",
	shortdesc="CONSUMABLE",
	class="FOOD",
	mass=4,
	icon=gfx.thing_icon_fruit,
	dungeon=gfx.thing_dungeon_fruit,
	foodval=500,
	fit_pouch = true,		
	on_consume=eatdrink
}

obj.gauntlets = {
    name="GAUNTLETS",
    type="THING",
    class="WEAPON",
    mass=33,
    icon=gfx.thing_icon_gauntlets,
    dungeon=gfx.thing_dungeon_gauntlets,
	flying_away=gfx.thing_dungeon_gauntlets,
	flying_toward=gfx.thing_dungeon_gauntlets,
	flying_side=gfx.thing_dungeon_gauntlets,
	methods = {
	    { "PUNCH", 0, CLASS_NINJA, method_physattack },
	    { "JAB", 0, CLASS_FIGHTER, method_physattack },
	    { "PUMMEL", 5, { CLASS_NINJA, SKILL_MARTIALARTS }, method_physattack }
	},
	base_range=10,
	base_tpower=10,
	impact=28,
	fit_sheath=false
}

obj.halberd = {
    name="HALBERD",
    type="THING",
    class="WEAPON",
    mass=42,
    icon=gfx.thing_icon_halberd,
    dungeon=gfx.thing_dungeon_halberd,
	flying_away=gfx.thing_dungeon_halberd,
	flying_toward=gfx.thing_dungeon_halberd,
	flying_side=gfx.thing_dungeon_halberd,
	methods = {
	    { "JAB", 0, CLASS_FIGHTER, method_physattack },
	    { "THRUST", 5, { CLASS_FIGHTER, SKILL_STABBING }, method_physattack },
	    { "CLEAVE", 6, { CLASS_FIGHTER, SKILL_SLASHING }, method_physattack }
	},
	base_range=10,
	base_tpower=50,
	impact=28,
	fit_sheath=true
}

obj.hammer = {
    name="HAMMER",
    type="THING",
    class="CLUB",
    mass=36,
    icon=gfx.thing_icon_hammer,
	dungeon=gfx.thing_dungeon_hammer,
	flying_away=gfx.thing_dungeon_hammer_away,
	flying_toward=gfx.thing_dungeon_hammer_towards,
	flying_side=gfx.thing_dungeon_hammer,
	methods = club_methods,
	base_tpower=35,
	base_range=10,
	impact=10,
    fit_sheath=true
}

obj.hat = {
    name="HAT",
	type="THING",
	class="HEAD",
	mass=5,
	icon=gfx.thing_icon_hat,
	dungeon=gfx.thing_dungeon_hat,
	fit_head = true,
	fit_chest = true,
	armor_str = 1,
	sharp_resist = 2,
	to_head = stat_bonus,
	from_head = stat_bonus_off,
	stat = STAT_WIS,
	stat_up = 60
}

obj.heart = {
	name="HEART",
	type="THING",
	shortdesc="CONSUMABLE",
	class="FOOD",
	mass=4,
	icon=gfx.thing_icon_heart,
	dungeon=gfx.thing_dungeon_heart,
	foodval=900,
	fit_pouch = true,		
	on_consume=eatdrink
}

obj.katana = clone_arch(obj.sword_samurai, {
    name="KATANA",
	bonus_power=5
} )

obj.leather_jerkin_f = {
	name = "LEATHER JACK",
	type="THING",
	class="TORSO",
	mass = 6,
	icon=gfx.thing_icon_leather_f,
	dungeon=gfx.clothes_brown,
	fit_torso=true,
	fit_chest=true,
	armor_str = 17,
	sharp_resist = 3,
	useless_thrown=true
}

obj.leather_pants_f = {
	name = "LEATHER PANTS",
	type="THING",
	class="LEGS",
	mass = 8,
	icon=gfx.thing_icon_leather_legs_f,
	dungeon=gfx.clothes_brown,
	fit_legs=true,
	fit_chest=true,
	armor_str = 20,
	sharp_resist = 3,
	useless_thrown=true
}

--[[
obj.mirrorshield = {

}
]]

obj.pernach = {
	name="PERNACH",
	type="THING",
	class="WEAPON",
	mass=31,
	icon=gfx.thing_icon_pernach,
	dungeon=gfx.mace,		
	methods = {
	    { "BASH", 1, { CLASS_FIGHTER, SKILL_BASHING }, method_physattack },
	    { "STUN", 3, { CLASS_FIGHTER, SKILL_BASHING }, method_physattack },
	    { "CRUSH", 6, { CLASS_FIGHTER, SKILL_BASHING }, method_physattack }
	},	
	base_range=10,
	base_tpower=32,
	impact=10,
	bonus_power=12,
	monster_def_factor=0.85,
	fit_sheath=true,
	hit_sound=snd.dink
}

obj.petrified = {
	name="STATUE",
	type="THING",
	class="PETRIF",
	mass=15,
	icon=gfx.thing_icon_petrified,
	dungeon=gfx.thing_dungeon_petrified,
	max_throw_power=18,
	impact=2
}

function obj.petrified:namechanger(id, who_look)
	if (exvar[id] and exvar[id].owner) then
		return dsb_get_charname(exvar[id].owner) .. " " .. self.name
	else
		return nil
	end
end

function obj.petrified:on_click(id)
	if (exvar[id] and exvar[id].in_altar) then
		return true
	else
		return nil
	end
end

obj.razor = {
    name="RAZOR",
    type="THING",
    class="WEAPON",
    mass=5,
    icon=gfx.thing_icon_razor,
	dungeon=gfx.dagger,
	flying_away=gfx.dagger_flying_away,
	flying_toward=gfx.dagger_flying_toward,
	flying_side=gfx.dagger_flying_side,
	fit_quiver=true,
	fit_pouch=true,
	missile_type=MISSILE_DAGGER,
	methods = {
		{ "STAB", 0, CLASS_NINJA, method_physattack },
		{ "SLASH", 1, CLASS_NINJA, method_physattack },
		{ "ASSASSINATE", 8, CLASS_NINJA, method_physattack }
	},			
	base_range=12,
	impact=45,
	hit_sound=snd.dink,
	can_stick = true,
	go_thru_bars = true
}	

obj.ruby = clone_arch(obj.emerald, {
    name="RUBY",
    icon=gfx.thing_icon_ruby,
    dungeon=gfx.gem_orange
} )

obj.sapphire = clone_arch(obj.emerald, {
    name="SAPPHIRE",
    icon=gfx.thing_icon_sapphire,
    dungeon=gfx.gem_blue
} )

obj.spear = {
    name="SPEAR",
    type="THING",
    class="WEAPON",
    mass=33,
    icon=gfx.thing_icon_spear,
    dungeon=gfx.thing_dungeon_spear,
	flying_away=gfx.thing_dungeon_spear_away,
	flying_toward=gfx.thing_dungeon_spear_towards,
	flying_side=gfx.thing_dungeon_spear,
	methods = {
	    { "THROW", 0, CLASS_NINJA, method_throw_obj },
	    { "JAB", 0, CLASS_FIGHTER, method_physattack },
	    { "THRUST", 5, { CLASS_FIGHTER, SKILL_STABBING }, method_physattack }
	},
	base_range=10,
	base_tpower=50,
	impact=28,
	fit_sheath=true
}

obj.tourmaline = clone_arch(obj.emerald, {
    name="TOURMALINE",
    icon=gfx.thing_icon_tourmaline,
    dungeon=gfx.thing_dungeon_gem_yellow
} )

obj.trident = {
    name="TRIDENT",
    type="THING",
    class="WEAPON",
    mass=39,
    icon=gfx.thing_icon_trident,
    dungeon=gfx.thing_dungeon_trident,
	methods = {
	    { "JAB", 0, CLASS_FIGHTER, method_physattack },
	    { "THRUST", 5, { CLASS_FIGHTER, SKILL_STABBING }, method_physattack },
	    { "WATERBREATHE", 3, { CLASS_WIZARD, SKILL_AIR }, method_waterbreathe }
	},
	base_range=10,
	base_tpower=50,
	impact=28,
	fit_sheath=true
}

obj.torch_soaked = {
    name="TORCH",
    type="THING",
    class="TORCH",
    shortdesc="SOAKED",
    mass=11,
    icon=gfx.icons[4],
    dungeon=gfx.torch,
    methods=swing_method,
    fit_sheath=true,
    fit_chest=true,
	impact=2,
	base_tpower = 8
}

-- *******************
-- * Armour of Night *
-- *******************

obj.helm_night = {
    name="HELM OF NIGHT",
	type="THING",
	class="HEAD",
	mass=35,
	icon=gfx.thing_icon_armet_black,
	dungeon=gfx.helmet2,
	fit_head = true,
	fit_chest = true,
	armor_str = 75,
	sharp_resist = 4,
	to_head = stat_bonus,
	from_head = stat_bonus_off,
	stat = STAT_AFI,
	stat_up = 70,
	hit_sound=snd.dink
}

obj.legplate_night = {
    name="POLEYN OF NIGHT",
	type="THING",
	class="LEGS",
	mass=90,
	icon=gfx.thing_icon_poleyn_black,
	dungeon=gfx.legplate,
	fit_legs = true,
	armor_str = 100,
	sharp_resist = 4,
	to_legs = stat_bonus,
	from_legs = stat_bonus_off,
	stat = STAT_STR,
	stat_up = 70,
	hit_sound=snd.dink
}

obj.torsoplate_night = {
    name="PLATE OF NIGHT",
	type="THING",
	class="TORSO",
	mass=140,
	icon=gfx.thing_icon_breastplate_black,
	dungeon=gfx.torsoplate,
	fit_torso = true,
	armor_str = 160,
	sharp_resist = 4,
	to_torso = stat_bonus,
	from_torso = stat_bonus_off,
	stat = STAT_DEX,
	stat_up = 70,
	hit_sound=snd.dink
}	

obj.footplate_night = {
    name="GREAVE OF NIGHT",
	type="THING",
	class="FEET",
	mass=35,
	icon=gfx.thing_icon_sabatons_black,
	dungeon=gfx.footplate,
	fit_feet = true,
	armor_str = 60,
	sharp_resist = 4,
	to_feet = stat_bonus,
	from_feet = stat_bonus_off,
	stat = STAT_AMA,
	stat_up = 70,
	hit_sound=snd.dink
}

obj.shield_night = {
    name = "SHIELD OF NIGHT",
	type="THING",
    	class="SHIELD",
    	mass=40,
    	icon=gfx.icons[111],
    	dungeon=gfx.shield,
    	methods = shield_methods,
    	armor_str = 60,
    	sharp_resist = 8,
	to_l_hand = stat_bonus,
	from_l_hand = stat_bonus_off,
    	stat = STAT_VIT,
    	stat_up = 130
}

-- ****************************
-- * DOORS, KEYS AND KEYHOLES *
-- ****************************
obj.door_brass = {
	type="DOOR",
	class="METAL",
	renderer_hack="LEFTRIGHT",
	front=gfx.door_brass,
	bash_mask=gfx.door_bashed,
	col=door_collide,
	msg_handler=door_msg_handler
}

obj.door_glass = {
	type="DOOR",
	class="RA",
	renderer_hack="MAGICDOOR",
	front=gfx.door_glass,
	bash_mask=gfx.door_bashed,
	col=door_collide,
	msg_handler=door_msg_handler,
	silent = true,
	thud_sound = snd.dink
}

obj.door_ornate = {
	type="DOOR",
	class="METAL",
	renderer_hack="LEFTRIGHT",
	front=gfx.door_ornate,
	bash_mask=gfx.door_bashed,
	col=door_collide,
	msg_handler=door_msg_handler
}

obj.key_brass = {
    name="BRASS KEY",
	type="THING",
	class="KEY",
	mass=1,
	icon=gfx.thing_icon_key_brass,
	dungeon=gfx.key_gold,
	fit_pouch=true,
	hit_sound=snd.dink
}

obj.key_flower = {
    name="FLOWER KEY",
	type="THING",
	class="KEY",
	mass=1,
	icon=gfx.thing_icon_key_flower,
	dungeon=gfx.key_gold,
	fit_pouch=true,
	hit_sound=snd.dink
}

obj.key_red = {
    name="RED KEY",
	type="THING",
	class="KEY",
	mass=1,
	icon=gfx.thing_icon_key_red,
	dungeon=gfx.key_gold,
	fit_pouch=true,
	hit_sound=snd.dink
}

obj.keyhole_brass = {
	type="WALLITEM",
	class="KEYHOLE",
	front=gfx.wallitem_keyhole_brass_front,
	side=gfx.wallitem_keyhole_brass_side,
	wall_patch=true,
	on_click=wallitem_click
}

obj.keyhole_flower = {
	type="WALLITEM",
	class="KEYHOLE",
	front=gfx.wallitem_keyhole_flower_front,
	side=gfx.wallitem_keyhole_flower_side,
	wall_patch=true,
	on_click=wallitem_click
}

obj.keyhole_red = {
	type="WALLITEM",
	class="KEYHOLE",
	front=gfx.wallitem_keyhole_red_front,
	side=gfx.wallitem_keyhole_red_side,
	wall_patch=true,
	on_click=wallitem_click
}

-- *************
-- * WALLITEMS *
-- *************
obj.altar = {
	type="WALLITEM",
	class="DECO",
	front=gfx.wallitem_altar_front,
	side=gfx.wallitem_altar_side,
	wall_patch=true,
	on_click=wallitem_click
}

obj.alcove_petrif = {
	type="WALLITEM",
	class="ALCOVE",
	front=gfx.wallitem_petrif_front,
	side=gfx.wallitem_petrif_side,
	on_click=use_petrif_alcove,
	msg_handler = vi_altar_msg_handler,
	revive_class = "PETRIF",
	drop_zone=true,
	ignore_empty_clicks=true
}

obj.alcove_petrif = clone_arch(obj.alcove_vi, {
    revive_class = "PETRIF",
   	front=gfx.wallitem_petrif_front,
	side=gfx.wallitem_petrif_side
} )

obj.banner = {
	type="WALLITEM",
	class="DECO",
	front=gfx.wallitem_banner_front,
	side=gfx.wallitem_banner_side,
	wall_patch=true,
	on_click=wallitem_click
}

obj.banner1 = {
	type="WALLITEM",
	class="DECO",
	front=gfx.wallitem_banner1_front,
	side=gfx.wallitem_banner1_side,
	wall_patch=true,
	on_click=wallitem_click
}

obj.collapse = {
	type="WALLITEM",
	class="DECO",
	front=gfx.wallitem_collapse_front,
	side=gfx.wallitem_collapse_side,
	wall_patch=true,
	on_click=wallitem_click
}

obj.cross = {
	type="WALLITEM",
	class="DECO",
	front=gfx.wallitem_cross_front,
	wall_patch=true,
	on_click=wallitem_click
}

obj.deerskull = {
	type="WALLITEM",
	class="DECO",
	front=gfx.wallitem_deerskull_front,
	side=gfx.wallitem_deerskull_side,
	wall_patch=true,
	on_click=wallitem_click
}

obj.hanged_man = {
	type="WALLITEM",
	class="DECO",
	front=gfx.wallitem_hanged_front,
	side=gfx.wallitem_hanged_side,
	wall_patch=true,
	on_click=wallitem_click
}

obj.painting_f = {
	type="WALLITEM",
	class="DECO",
	front=gfx.wallitem_painting_front_f,
	side=gfx.wallitem_painting_side,
	wall_patch=true,
	on_click=wallitem_click
}

obj.painting_m = {
	type="WALLITEM",
	class="DECO",
	front=gfx.wallitem_painting_front_m,
	side=gfx.wallitem_painting_side,
	wall_patch=true,
	on_click=wallitem_click
}

obj.skeleton_wall = {
	type="WALLITEM",
	class="DECO",
	front=gfx.wallitem_skeleton_front,
	side=gfx.wallitem_skeleton_side,
	wall_patch=true,
	on_click=wallitem_click
}

obj.skull_wall = {
	type="WALLITEM",
	class="DECO",
	front=gfx.wallitem_skull_front,
	wall_patch=true,
	on_click=wallitem_click
}

obj.statue_wall = {
	type="WALLITEM",
	class="DECO",
	front=gfx.wallitem_statue_front,
	side=gfx.wallitem_statue_side,
	wall_patch=true,
	on_click=wallitem_click
}

obj.sunpainting = {
	type="WALLITEM",
	class="DECO",
	front=gfx.wallitem_sunpainting_front,
	side=gfx.wallitem_sunpainting_side,
	wall_patch=true,
	on_click=wallitem_click
}

obj.swords = {
	type="WALLITEM",
	class="DECO",
	front=gfx.wallitem_swords_front,
	side=gfx.wallitem_swords_side,
	wall_patch=true,
	on_click=wallitem_click
}

obj.tapestry = {
	type="WALLITEM",
	class="DECO",
	front=gfx.wallitem_tapestry_front,
	side=gfx.wallitem_tapestry_side,
	wall_patch=true,
	on_click=wallitem_click
}

-- **************
-- * FLOORITEMS *
-- **************
obj.floorstatue = {
    type="FLOORUPRIGHT",
    class="STATUE",
    col = true,
    front=gfx.floorflat_statue
}

obj.minostatue = clone_arch(obj.floorstatue, {
	front=gfx.floorflat_minostatue
} )

obj.floorstatue_2 = clone_arch(obj.floorstatue, {
	front=gfx.floorflat_statue_2
} )

obj.floorstatue_3 = clone_arch(obj.floorstatue, {
	front=gfx.floorflat_statue_3
} )

obj.floorstatue_4 = clone_arch(obj.floorstatue, {
	front=gfx.floorflat_statue_4
} )

obj.chandelier = clone_arch(obj.movablewall, {
	class="STATUE",
	front=gfx.floorflat_chandelier
} )

obj.corpsecage = clone_arch(obj.movablewall, {
	class="STATUE",
	front=gfx.floorflat_corpsecage
} )

-- ********************
-- * CHAMPION HOLDERS *
-- ********************
obj.prisoner_yvonne = {
	type="WALLITEM",
	class="CHAMPION_HOLDER",
	no_party_clickable=true,
	default_silent=true,
	front=gfx.champion_prisoner_yvonne,
	side=gfx.mirror_side,
	mirror_inside=gfx.mirror_inside,
	esb_mirror=true
}

function obj.prisoner_yvonne:on_click(id, clicked_with)
	if (clicked_with == nil and exvar[id]) then
		local inside = exvar[id].champion
		if (inside) then
			local offer_mode = 3
			if (exvar[id].offer_mode) then
				offer_mode = exvar[id].offer_mode
			end
			dsb_offer_champion(inside, offer_mode, function ()
				exvar[id].champion = nil
				got_triggered(id, nil)
			end)
		end
	end
end

obj.prisoner_wort = {
	type="WALLITEM",
	class="CHAMPION_HOLDER",
	no_party_clickable=true,
	default_silent=true,
	front=gfx.champion_prisoner_wort,
	side=gfx.mirror_side,
	mirror_inside=gfx.mirror_inside,
	esb_mirror=true
}

function obj.prisoner_wort:on_click(id, clicked_with)
	if (clicked_with == nil and exvar[id]) then
		local inside = exvar[id].champion
		if (inside) then
			local offer_mode = 3
			if (exvar[id].offer_mode) then
				offer_mode = exvar[id].offer_mode
			end
			dsb_offer_champion(inside, offer_mode, function ()
				exvar[id].champion = nil
				got_triggered(id, nil)
			end)
		end
	end
end

obj.prisoner_helen = {
	type="WALLITEM",
	class="CHAMPION_HOLDER",
	no_party_clickable=true,
	default_silent=true,
	front=gfx.champion_prisoner_helen,
	side=gfx.mirror_side,
	mirror_inside=gfx.mirror_inside,
	esb_mirror=true
}

function obj.prisoner_helen:on_click(id, clicked_with)
	if (clicked_with == nil and exvar[id]) then
		local inside = exvar[id].champion
		if (inside) then
			local offer_mode = 3
			if (exvar[id].offer_mode) then
				offer_mode = exvar[id].offer_mode
			end
			dsb_offer_champion(inside, offer_mode, function ()
				exvar[id].champion = nil
				got_triggered(id, nil)
			end)
		end
	end
end

-- ********
-- * MISC *
-- ********
obj.mindblast = clone_arch(obj.desewspell, {
   name="MIND BLAST",
   dungeon=gfx.misc_mindblast,
   flying_away=gfx.misc_mindblast,
   flying_toward=gfx.misc_mindblast,
   flying_side=gfx.misc_mindblast, 
   flying_hits_nonmat=false,   
   on_location_explode=psychic_explode_square
} )